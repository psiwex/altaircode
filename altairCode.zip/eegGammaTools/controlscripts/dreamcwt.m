%dreams notes: annotated channel is first for subjects 1-6, but 3rd on
%subjects 7 and 8
subnum=1;
scales1=[.5 2.5];
scales1=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));

%scales1=[.125 .25 .5 1];
%scales1=[.5 1 1.5 2 2.5];
atoms=200;
bounds=[10 26];
%bounds=[12 15];
maxatoms=1000;
clear x;
ss=1;
bars=[1 5:10:95 99];
%for bar=1:length(bars);
 %   bb=bars(bar);
    %for ss=0:(length(scales1)-1)
        scales=scales1(1:(length(scales1)-ss));
        clc;
        
   %     for jj=atoms:200:maxatoms;
            values=jj;
            clc;
            
            for subnum=1:8
                filename=['excerpt' num2str(subnum) '.set'];
                clc;
                EEG = pop_loadset(filename);
                
                EEG=pop_resample(EEG,128);
                expertname=['expert_events' num2str(subnum) '.mat'];
                
                load(expertname);
                
                %%
                
                if subnum>6
                    
                    channel_index = 3;
                    
                else
                    channel_index=1;
                    
                end
                
                %x=EEG.data;
                %% reconstruct signal
                
                % plot ROC curves for each
                %EEG = pop_eegfiltnew(EEG,bounds(1),bounds(2)); clc;
           % [output_as]=spindledetectorUnsupervisedCWT(EEG,channel_index,expert_events,values,bounds,scales);
            
            [output_cwt]=spindledetectorUnsupervisedCWT(EEG,channel_index,expert_events,bounds);
                    
%            [output_dar]=spindledetectorSDARphi(pop_eegfiltnew(EEG,bounds(1),bounds(2)),channel_index,expert_events);
%             [output_rd]=spindledetectorRestrictedDictionaryphi(EEG,channel_index,expert_events,values,bounds,scales);
%             [output_wd]=spindledetectorAdjustphi(EEG,channel_index,expert_events,values,bounds,scales);
%             [output_bp]=spindledetectorAdjustBPphi(EEG,channel_index,expert_events,values,bounds,scales);
%             
%                 filename1=['dream2_score_phid_dar' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%                 save(filename1,'output_dar');
%                 
%                 filename1=['dream2_score_phid_rd' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%                 save(filename1,'output_rd');
%                 
%                 filename1=['dream2_score_phid_wd' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%                 save(filename1,'output_wd');
%                 
                 filename1=['dream2_score_phid_cwt' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
                 save(filename1,'output_cwt');
                 clear x;
                
                
           % end
            
        %end
    end
%end

%scales1=[.125 .25 .5 1];
filename='data/driving-data1.set';
load data/subject1010v2;
channel_index = 25:26;
atoms=200;
%bounds=[12 15];

EEG = pop_loadset(filename);
clc;
subnum=11;
ss=1;
%for bar=1:length(bars);
 %   bb=bars(bar);
    %for ss=0:(length(scales1)-1)
        scales=scales1(1:(length(scales1)-ss));
        clc;
        
       % for jj=atoms:200:maxatoms;
            values=jj;
            clc;
            
            [output_cwt]=spindledetectorUnsupervisedCWT(EEG,channel_index,expert_events,bounds);
                
%             
%             [output_dar]=spindledetectorSDARphi(pop_eegfiltnew(EEG,bounds(1),bounds(2)),channel_index,expert_events);
%             [output_rd]=spindledetectorRestrictedDictionaryphi(EEG,channel_index,expert_events,values,bounds,scales);
%             [output_wd]=spindledetectorAdjustphi(EEG,channel_index,expert_events,values,bounds,scales);
%             [output_bp]=spindledetectorAdjustBPphi(EEG,channel_index,expert_events,values,bounds,scales);
%             
%             filename1=['drive2_score_phid_dar' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%             save(filename1,'output_dar');
%             
%             filename1=['drive2_score_phid_rd' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%             save(filename1,'output_rd');
%             
%             filename1=['drive2_score_phid_wd' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
%             save(filename1,'output_wd');
            
            filename1=['drive_score_phid_cwt' num2str(subnum) 'atoms' num2str(jj) 'scalelength' num2str(length(scales)) '.mat'];
            save(filename1,'output_cwt');
            
            
            clear x;
            
       % end
    %end
%end
