function [c1]=compareThresholdROC(EEG, expert_events, smoothed, thresholds)


%--------------------------------------------------------------------------
% compareThreshold

% Last updated: June 2016, J. LaRocco

% Details: MP reconstruction of EEG with restricted dictionary.

% Usage:
% [c1]=compareThreshold(EEG, expert_events, smoothed, thresholds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  smoothed: reconstruction of EEG data (vector)
%  threshold: vector of values to explore for threshold (vector)
% Output:
%  c1: struct with final results

%--------------------------------------------------------------------------

TP=zeros(1,length(thresholds));
TN=zeros(1,length(thresholds));
FP=zeros(1,length(thresholds));
FN=zeros(1,length(thresholds));
specificity1=zeros(1,length(thresholds));
NPR1=zeros(1,length(thresholds));
recall1=zeros(1,length(thresholds));

%% Apply threshold for classification

for K = 1 : length(thresholds)
    Px=pow2db(sum(abs(fft(smoothed(1,:).^2)))/length(smoothed));
    events = applyThreshold(smoothed, EEG.srate, thresholds(K), 1/3);
    if isempty(events)
        continue
    end
    new_events = combineEvents(events, .25, .25);
    
    
    [~,~,c] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
    
    labels=zeros(1,length(smoothed));
    scores=labels;
    
    [keyEvents,~]=size(expert_events);
    [newEvents,~]=size(new_events);
    for ja=1:keyEvents;
        keystart=expert_events{ja,2};
        keyend=expert_events{ja,3};
        
        lb=ceil(EEG.srate*keystart);
        ub=ceil(EEG.srate*keyend);
        labels(lb:ub)=1;
        
    end
    
    for jb=1:newEvents
        
        lb=ceil(EEG.srate*keystart);
        ub=ceil(EEG.srate*keyend);
        scores(lb:ub)=1;
    end
    
    specificity1(K) = (c.nullAgreement)/ceil(c.nullAgreement+c.falsePositive);
    recall1(K) = (c.agreement)/ceil(c.agreement+c.falseNegative);
    NPR1(K)=1-specificity1(K);
    
    tp=(c.agreement);
    tn=(c.nullAgreement);
    fp=(c.falsePositive);
    fn=(c.falseNegative);
    
    TP(K)=tp;
    TN(K)=tn;
    FP(K)=fp;
    FN(K)=fn;
    
end
%% tally up performance metrics

x=[1 0 1 recall1]';
y=[0 0 1 NPR1]';

dt=delaunayTriangulation(x,y);
convexPts=convexHull(dt);

rocx=x(convexPts);
rocy=y(convexPts);

rocx=rocx(3:end);
rocy=rocy(3:end);
clc;
aucs=zeros(1,length(rocx)-1);

rocx1=rocx;
rocy1=rocy;


for ii=1:(length(rocx1)-1);
    h=abs(rocx1(ii)-rocx1(ii+1));
    a=rocy1(ii);
    b=rocy1(ii+1);
    
    
    aucs(ii)=h*(a+b)./2;
    
end
aucroc(K)=sum(aucs);

[~,b] = max(recall1);

%%
events = applyThreshold(smoothed, EEG.srate, thresholds(b), 1/3);
new_events = combineEvents(events, .25, .25);

[~,~,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);

c1.X=x;
c1.Y=y;
c1.aucs=aucs;

c1.thresholds=thresholds(b);

%%
EEG.event = [];
temp1(size(expert_events,1)).type = [];
temp1(size(expert_events,1)).latency = [];

for i = 1 : size(expert_events, 1)
    temp1(i).type = 'start';
    temp1(i).latency = cell2mat(expert_events(i, 2))*EEG.srate;
    
end

for j = i+1 : 2*size(expert_events, 1)
    temp1(j).type = 'end';
    temp1(j).latency = cell2mat(expert_events(j-size(expert_events, 1), 3))*EEG.srate;
    
end
EEG.event = temp1;

c1.auc=aucroc;
c1.selectedthreshold=thresholds(b);
c1.thresholdvalues=thresholds;
c1.tp=TP;
c1.tn=TN;
c1.fp=FP;
c1.fn=FN;
c1.Px=Px;
end