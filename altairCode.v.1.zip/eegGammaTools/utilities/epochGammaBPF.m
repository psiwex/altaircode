function [pf1,pf2,pv1,pv2,power1,power2] = epochGammaBPF(input,infochannel,prelate,postlate,tone_session_start,tone_session_end,desired_channels)

%--------------------------------------------------------------------------
 % EPOCHGAMMABPF

 % Last updated: Jan 2016, J. LaRocco

 % Details: This will reject any epochs and then return lower gamma (1st column of pv1
%           and pv2) and upper gamma (2nd column of pv1 and pv2) band features, and a 
%           power ratio for before (power1) and after stimulus (power2). You also 
%           need time pre-stimulus (prelate). You also need the channels that you 
%           would like (desired_channels), and the start/end for the segment of EEG 
%           you want. 
%           Note on format: EEG information stored as:
%           [channel x epoch x samples] after it comes out of epoch format program.
%           Before this, it should be [channels x samples] in format.
 %  Usage: [pf1,pf2,pv1,pv2,power1,power2] = epochGammaWelch(input,infochannel,prelate,postlate,tone_session_start,tone_session_end,desired_channels)

 
 % Input: 
 %  input: Matrix of EEG data. 
 %  infochannel: binary channel of events and epochs. 
 %  prelate: samples before event to retain in epochs. 
 %  postlate: samples after event to retain in epochs.
 %  tone_session_start: sample where stimulus starts.
 %  tone_session_end: sample where stimulus ends.
 %  desired_channels: channels to keep. 
 
 % Output: 
 % pf1: pre-stimulus matrix of gamma features by epochs.
 % pf2: post-stimulus matrix of gamma features by epochs. 
 % p1: pre-stimulus power ratio cells.
 % p2: post-stimulus power ratio cells.
 % pv1: pre-stimulus low gamma (30-60 hz) and high gamma (60-120) power.
 % pv2: post-stimulus low gamma (30-60 hz) and high gamma (60-120) power.
    
    
%--------------------------------------------------------------------------





%% Power Feature calculation
eeg=input;
[chans1,leng]=size(eeg);

%tone_session_end=leng;



%eeg=eeg(i,:);


[epoch] = epochFormat(eeg,infochannel,prelate,postlate);
[pf1,pf2,pv1,pv2,power1,power2] = bpfGammaFeatureExtraction(epoch,prelate);

end