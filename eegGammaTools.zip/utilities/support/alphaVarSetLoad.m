function [EEG,chanNums] = alphaVarSetLoad(sites,subnum,session)

%--------------------------------------------------------------------------
% alphaVarSetLoad

% Last updated: August 2016, J. LaRocco

% Details: Load alpha variability sets

% Usage:
% [EEG,chanNums] = alphaVarSetLoad(sites,subnum,session)

% Input:
%  sites: channel to use
%  subnum: subject number
%  session: session number. r01-open, r02-closed

% Output:
%  EEG: Output EEG struct. (EEGLAB format)
%  chanNums: Number of channels for each site. (Vector)


%--------------------------------------------------------------------------


%sites = {'F3','Fz','F4','C3','Cz','C4','P3','Pz','P4','O1','Oz','O2'};

if subnum<100
    
    filename=['S0' num2str(subnum) 'R0' num2str(session) '.set'];
    clc;
    
else
    filename=['S' num2str(subnum) 'R0' num2str(session) '.set'];
    clc;
    
end

if subnum<10
    
    filename=['S00' num2str(subnum) 'R0' num2str(session) '.set'];
    clc;
    
end

EEG = pop_loadset(filename);


for s = 1:length(sites)
    chanNums(s) = strmatch(sites{s}, {EEG.chanlocs.labels});
end


end



