function EEG = medOpenRawTruncate(filename)
% Extracts the EEG from raw data and truncates it
%
%  Input:
%    filename-        name of the EDF file
%
%   Output:
%     EEG-            EEGLAB EEG structure
%
%   Written by:  John LaRocco
%
% Assumes:  EDF files are all continuous.
%

%% Read the data from the EDF file
[hdr, data] = edfread(filename);

%% Set basic information fields of the EEG structure
EEG = eeg_emptyset();
EEG.fileName = filename;
EEG.comments = 'File source Valerie Rice San Antonio';
EEG.nbchan = size(data, 1);
EEG.trials = 1;
EEG.pnts = size(data, 2);

%% Fix the channel names and types.
labels = hdr.label;
chanlocs(length(labels)) = struct('theta', [], 'radius', [], ...
                       'labels', [], 'sph_theta', [], 'sph_phi', [], ...
                       'X', [], 'Y', [], 'Z', [], ...
                       'sph_theta_besa', [],  'sph_phi_besa', [],...
                       'type', [], 'ref', [], 'urchan', []); 

%for k = 1:length(labels)
%     startLabel = labels{k}(1:3);
%     restLabel = labels{k}(4:end);
%     chanlocs(k).type = startLabel;
%     chanlocs(k).urchan = k;
%     ref = strfind(restLabel, 'Ref');
%     if ~isempty(ref)
%         restLabel = restLabel(1:end-3);
%     end
%     if strcmpi(startLabel, 'POL')
%        chanlocs(k).labels = labels{k};
%     else
%        chanlocs(k).labels = restLabel;
%     end
% end

%% Read a channel file and map channel locations to actual locations


EEG.data = data;

samples=hdr.samples;
%% Check the sampling rate for the EEG channels now we know which are EEG
%samples = hdr.samples(EEGTypes & ~emptyX);
EEG.srate = samples(1)/hdr.duration;
samples(2:end) = samples(2:end) - samples(1);
if sum(abs(samples(2:end))) > 10e-12
%    warning('EEG channels have different sampling rates');
end
EEG.xmin = 0;
EEG.xmax = (EEG.pnts - 1)/EEG.srate;
EEG.times = 1000*(0:EEG.pnts-1)/EEG.srate;
load Topoplot_Parameters_X10.mat
EEG_ChnNum_Start = 1;
EEG_ChanNum_End = 10;
nbchan= EEG_ChanNum_End - EEG_ChnNum_Start +1;    
EEG.nbchan=nbchan;
EEG.pnts=length(EEG.data(1,:,:));
%EEG.srate=256;
%EEG.times=0:(1000/256):100000000;
EEG.times=EEG.times(1:EEG.pnts);

EEG.data=EEG.data(1:nbchan,:);
%dataclean
dat=EEG.data;
[chans,samples]=size(dat);
shorts=[];
for ii=1:chans;
x=data(ii,:);
c=find(x==0);
shorts(:,ii)=c(1);
end;
mark=min(shorts);

EEG.data=EEG.data(:,1:mark);
EEG.pnts=mark;
%EEG.times=EEG.times(1,1:mark);
EEG.xmax = (EEG.pnts - 1)/EEG.srate;
EEG.times = 1000*(0:EEG.pnts-1)/EEG.srate;
EEG.fileName=[filename '.set'];
EEG.filename=[filename '.set'];
EEG.chanlocs=st_Channel_Grid(1,EEG_ChnNum_Start:EEG_ChanNum_End);
EEG.chaninfo=st_Channel_Info(1,1);
EEG.saved='yes';
%[ALLEEG EEG index] = eeg_store(ALLEEG, EEG);
%% Now sort the event latencies in increasing order.
% [sortedTimes, sortedIndex] = sort(eTimes);
% event(length(eTimes)) = struct('type', [], 'latency', [], 'urevent', []);
% for k = 1:length(event)
%   event(k).latency = sortedTimes(k);
%   event(k).type = getEventName(eventTypes(sortedIndex(k)));
%   event(k).urevent = k;
% end
% urevent = event;
% urevent = rmfield(urevent, 'urevent');
% EEG.event = event;
% EEG.urevent = urevent;



end
