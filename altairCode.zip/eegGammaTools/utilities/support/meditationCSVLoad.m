function eventTimes=meditationCSVLoad(filename,fs)


%--------------------------------------------------------------------------
% meditationCSVLoad

% Last updated: March 2016, J. LaRocco

% Details: Function loads a string with a timestamp formatted as
% "hour:minute:second:millisecond" and converts to seconds.

% Usage: eventTimes=meditationCSVLoad(filename,fs)

% Input:
%  filename: name of CSV file of events.
%  fs: sampling frequency.

% Output:
%  eventTimes: A matrix of 3 by number of events. eventTimes(1,:) is time
%  in seconds for an event, and eventTimes(2,:) is sample number for an
%  event.

%  eventTimes(3,:) is the code for each event. 

% Word (i.e., read a word printed in black): 1 
% Color Non-word (i.e., name the font color of 'XXXX'): 2 
% Color Word (i.e., name the font color of a color word): 3  
% Triggers to mark a response: Correct response: 7
% Incorrect response: 8 
% Incorrect response in which the subject responded with the read word rather than the font color: 9
% End of session: 0


%--------------------------------------------------------------------------






%% load file
[main.utc, main.fd, x]= textread(filename, '%s %s %s', 'delimiter', ',');
%% find relevant time events
indices = strfind(x, ':');
indexlength=length(x);

indexFilled=zeros(1,indexlength);

for lovecraft=1:indexlength;
    contentsofCell=indices{lovecraft};
    
    if isempty(contentsofCell);
        
        indexFilled(lovecraft)=0;
    else
        indexFilled(lovecraft)=1;
    end
    
    
end




times=find(indexFilled==1);

x1=x{times(1)};
%startDateString = [num2str(startMonth) '/' num2str(startDay) '/' num2str(startYear)];

timeSec=meditationTimeConversion(x1);

startTime=round(timeSec);
startSample=startTime*fs;

%% prepare the output matrix

eventTimes=zeros(3,(length(times)-1));

for pickman=1:length(eventTimes);
    
    x1=x{times(pickman+1)};
    
    x3=str2num(strrep(x1,':',';'));
    
    timeSec=meditationTimeConversion(x1);
    
    timePoint=round(timeSec-startTime);
    samplePoint=timePoint*fs;
    
    eventTimes(1,pickman)=timePoint;
    eventTimes(2,pickman)=samplePoint;
   
    
    if pickman==length(eventTimes);
    eventTimes(3,pickman)=0;
        
    else    
    eventTimes(3,pickman)=str2double(x{(times(pickman+1)+1)});
    end;


end





end