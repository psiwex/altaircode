function [weiMaxFreq,unweiMaxFreq,peaMaxFreq] = wvMPFreqFinder(EEG,channel_index,findRange,wins,atoms,scales)

%--------------------------------------------------------------------------
% wvMPFreqFinder

% Last updated: July 2016, J. LaRocco

% Details: Wigner-Ville maximum frequency finder. Requires Time-Frequency
% toolbox.

% Usage:
% [weiMaxFreq,unweiMaxFreq,peaMaxFreq]= wvMPFreqFinder(EEG,channel_index,findRange,wins)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  findRange: a binary vector of frequencies to limit the transform to (e.g., [8 12])
%  wins: Scalar value. Window length in samples (preferably with length in respect to sampling rate (e.g., ceil(.25*EEG.srate))
%  atoms: number of atoms (scalar)
%  scales: vector of scale values

% Output:
%  weiMaxFreq: Weighted Max frequency
%  unweiMaxFreq: Unweighted Max frequency
%  peaMaxFreq: peak frequency

%--------------------------------------------------------------------------

Fs = EEG.srate;


%% calculate max frequencies

for k = 1 : length(channel_index)
    [y,~] = mpRDReconstruct(EEG,channel_index(k),atoms,findRange,scales);

    %% Wigner Ville
    
    [tfr,t0,F] = tfrwv(y');
    
    % convert to log scale
    tfr=10*log10(abs(tfr));
    
    %% remove all but alpha band
    freqConvert=round(Fs*F);
    lowerRange=find(freqConvert==findRange(1));
    lowerRange=lowerRange(1);
    upperRange=find(freqConvert==findRange(2));
    upperRange=upperRange(1);
    %tfr=tfr(lowerRange:upperRange,:);
    tfr1=tfr(lowerRange:upperRange,:);
    tfr2=zeros(size(tfr));
    tfr2(lowerRange:upperRange,:)=tfr1;
    tfr=tfr2;
    
    %% Gravity
    unweightedFreq = zeros(length(F), length(t0));
    weightedFreq = zeros(1, length(t0));
    peakFreq=zeros(1,length(t0));
    peakPower=zeros(1,length(t0));
    totalPower = sum(tfr, 1);
    for kk = 1:length(t0)
        weightedFreq(kk) = (tfr(:, kk)'*F)/totalPower(kk);
        unweightedFreq(:,kk) = tfr(:, kk)./totalPower(kk);
        [maxval,maxind]=max(tfr(:, kk));
        peakFreq(kk)=F(maxind);
        peakPower(kk)=maxval;
    end
    %weightedFreq = weightedFreq./totalPower;
    %unweightedFreq = unweightedFreq./totalPower;
    
    
    
    
    %% Smoothing
    %% Windowing with respect to FS
    %wins=ceil(.25*Fs);
    
    %% windowing modified loops
    ll=zeros(1,length(t0));
    uu=zeros(1,length(t0));
    for i=1:ceil((length(t0)));
        ll(i)=ceil((i-1)*.5*wins)+1;
        uu(i)=ceil(.5*wins*i);
    end
    
    ll=ll(ll<length(t0));
    uu=uu(uu<=length(t0));
    
    maxFreqsw=zeros(1,length(uu));
    maxFreqsu=zeros(1,length(uu));
    maxFreqsp=zeros(1,length(uu));
    
    for i=1:length(uu);
        maxFreqsw(:,i)=mean(weightedFreq(ll(i):uu(i)),2);
        maxFreqsu(:,i)=mean(mean(unweightedFreq(:,ll(i):uu(i))),2);
        maxFreqsp(:,i)=mean(peakFreq(ll(i):uu(i)),2);
    end
    
    
    
    weightedMaxFreq=Fs*maxFreqsw;
    unweightedMaxFreq=Fs*maxFreqsu;
    peakMaxFreq=Fs*maxFreqsp;
    
    if k==1;
        
        weiMaxFreq=zeros(length(channel_index),length(weightedMaxFreq));
        unweiMaxFreq=zeros(length(channel_index),length(unweightedMaxFreq));
        peaMaxFreq=zeros(length(channel_index),length(peakMaxFreq));
        
    end
    
    weiMaxFreq(k,:)=weightedMaxFreq;
    unweiMaxFreq(k,:)=unweightedMaxFreq;
    peaMaxFreq(k,:)=peakMaxFreq;
    
end



end



