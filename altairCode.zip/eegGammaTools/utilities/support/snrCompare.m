function snr = snrCompare(x,bnds,fs)
% calculate rough SNR
%
%  Parameters:
% x: 2d matrix of time series data
% bnds: 2 element array for filter
% fs: sampling frequency
% snr: output as percent

x1 = bandpass(x,bnds,fs);
N=length(x);


N = length(x);
xdft = fft(x);
xdft = xdft(1:N/2+1);
psdx = (1/(fs*N)) * abs(xdft).^2;
psdx(2:end-1) = 2*psdx(2:end-1);
psdRaw=pow2db(psdx);

xdft = fft(x1);
xdft = xdft(1:N/2+1);
psdx = (1/(fs*N)) * abs(xdft).^2;
psdx(2:end-1) = 2*psdx(2:end-1);
psdFil=pow2db(psdx);

%snr=sum(abs(psdFil))/sum(abs(psdRaw));
snr=sum((psdFil))-sum((psdRaw));

