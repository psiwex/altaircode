function [Pxx,power]=featuresGMP(epochs,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESGMP

% Last updated: Feb 2016, J. LaRocco

% Details: Feature extraction method, using matching pursuit with Gabor
% atoms. Based on code from P. Mineault:
% http://www.mathworks.com/matlabcentral/fileexchange/32426-matching-pursuit-for-1d-signals

% Usage: [y,power]=featuresGMP(segments,fs)

% Input:
%  epochs: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx is the spectral feature vector.
% power: power is the raw spectrum.

%--------------------------------------------------------------------------


[samples,chan]=size(epochs);

Pxx=zeros(34,chan);
power=[];


rg = ((-fs/2):(fs/2))';
sigmas = exp(log(2):.3:log(200));
gabors = exp(-.5*(rg.^2)*sigmas.^(-2)).*cos(rg*sigmas.^(-1)*2*pi*2);


for i=1:chan;
    
    yith=epochs(:,i);
    
    
    
    [ws,yhat] = temporalMP(prototype_cleanup(yith'),gabors,false,20); clc;
    
    pv=(pwelch(yhat',[],10,[],fs));
    if i==1
        power=zeros(length(pv),chan);
    end
    
    
    
    spec_coefs=pow2db(abs(pv));
    
    [spectral_coefs]=featureSpecOrganizer(spec_coefs);
    
    
    
    Pxx(:,i)=spectral_coefs;
    power(:,i)=spec_coefs;
end



end
