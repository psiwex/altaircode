function [events,finalEvents,scales,freqs,times] = mpUnsupervisedSpindleDetector(ws,channel_index,featurestouse,sigmaFreq,EEG)

%--------------------------------------------------------------------------
% mpUnsupervisedFeatureFinder

% Last updated: August 2016, J. LaRocco

% Details: MP unsupervised feature finding and threshold ranking for 
%          spindle detection.

% Usage:
% [finalEvents,scales,freqs,times] = mpUnsupervisedSpindleDetector(ws,channel_index,featurestouse,sigmaFreq,EEG)

% Input:
%  ws: a matrix of MP coefficients (matrix of channels by time by freq/scale)
%  channel_index: A vector of channels to limit analysis to.
%  featurestouse: Number of features to retain (scalar)
%  sigmaFreq: 2 column matrix with scale values in 1st column, freq in 2nd
%  EEG: EEG struct

% Output:
%  finalEvents: final classification vector (1=event and 0=none)
%  scales: matrix containing scale values of top features (which descend)
%  freqs: matrix holding freq values of top features (which descend)
%  times: matrix containing times of top features (which descend)


%--------------------------------------------------------------------------

ratinglist=zeros(featurestouse,size(squeeze(ws(channel_index(1),:,:)),1));
channelratings=zeros(length(channel_index),size(squeeze(ws(channel_index(1),:,:)),1));
ratingvector=zeros(1,size(squeeze(ws(channel_index(1),:,:)),1));
info=zeros(2,featurestouse);
scales=zeros(featurestouse,length(channel_index));
freqs=zeros(featurestouse,length(channel_index));
times=zeros(featurestouse,length(channel_index));
eventDur=zeros(2,featurestouse*length(channel_index));
events = cell(featurestouse*length(channel_index), 3);
% use energy from all channels, .5-2.5, 12-15 hz, abs/square of gabor atoms
% indept of time and phase, plot freq vs. amplitude
for k = 1 : length(channel_index)
    x=squeeze(ws(channel_index(k),:,:));
    xx=reshape(x,1,size(x,1)*size(x,2));
    xx=sort(xx,'descend');
    xx=xx(1,1:featurestouse);
    
    for ii=1:featurestouse
        [info(1,ii),info(2,ii)]=find(x==xx(ii));
        
        scale=sigmaFreq(info(2,ii),1);
        freq=sigmaFreq(info(2,ii),2);
        
        scales(ii,k)=scale;
        freqs(ii,k)=freq;
        times(ii,k)=info(1,ii);
        
        mark=ceil(scale*EEG.srate);
        lm=info(1,ii)-mark;
        hm=info(1,ii)+mark;
        
        if lm<1
            lm=1;
        end
        
        if hm>size(x,1)
            hm=size(x,1);
        end
        
        ratingvector(lm:hm)=1;
        eventDur(1,ii*k)=lm/EEG.srate;
        eventDur(2,ii*k)=(hm-lm)/EEG.srate;
        
        
        
        ratinglist(ii,:)=ratingvector;
    end
    finalvector=round(sum(ratinglist));
    finalvector(finalvector>1)=1;
    finalvector(finalvector<0)=0;
    channelratings(k,:)=finalvector;
    
end

[reorderedEvents,eventInd]=sort(eventDur(1,:),'ascend');
r=eventDur(2,:);
r=r(eventInd);

eventDur(1,:)=reorderedEvents;
eventDur(2,:)=r;

finalEvents=round(mean(channelratings));
finalEvents(finalEvents>1)=1;
finalEvents(finalEvents<0)=0;


for i = 1 : (featurestouse*length(channel_index))
    events{i, 1} = 'alphaspindle';
    events{i, 2} = eventDur(1,i);
    events{i, 3} = eventDur(2,i);
end

end



