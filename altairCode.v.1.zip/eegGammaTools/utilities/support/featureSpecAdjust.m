function [specCo]=featureSpecAdjust(spec_coefs,fs)


%--------------------------------------------------------------------------
% FEATURESPECADJUST

% Last updated: Feb 2016, J. LaRocco

% Details: Feature sorting method, normalizing with respect to frequency.

% Usage: [specCo]=featureSpecAdjust(spec_coefs,fs)

% Input:
%  spec_coefs: spectral feature vector normalized to sampling frequency
%  fs: sampling frequency

% Output:
% specCo: specCo is the spectral feature vector.


%--------------------------------------------------------------------------


    maxSpectralCoef=max(spec_coefs);
    %spec_coefs=10*abs(log10(pv));
    spec_coefs=prototype_cleanup(spec_coefs);
    %mean spectral power

    deltaRange=ceil(([1:5]/(fs/2)));
    thetaRange=ceil(([5:9]/(fs/2)));
    
    alphaRange1=ceil(([9:11]/(fs/2)));
    alphaRange2=ceil(([11:13]/(fs/2)));
    alphaRange=ceil(([9:13]/(fs/2)));
    
    betaRange1=ceil(([13:17]/(fs/2)));
    betaRange2=ceil(([17:27]/(fs/2)));
    betaRange=ceil(([13:27]/(fs/2)));
    
    gammaRange1=ceil(([27:59]/(fs/2)));
    gammaRange2=ceil(([59:124]/(fs/2)));
    gammaRange=ceil(([27:124]/(fs/2)));
    
    highRange=ceil(([48:124]/(fs/2)));
    allRange=ceil(([1:124]/(fs/2)));
        %% Spectral Band Feature calculation
    %mean spectral power
    delta=mean([spec_coefs(deltaRange)]); %0-4 Hz
    theta=mean([spec_coefs(thetaRange)]); %4-8 Hz
    
    alpha_1=mean([spec_coefs(alphaRange1)]); %8-10 Hz
    alpha_2=mean([spec_coefs(alphaRange2)]); %10-12 Hz
    alpha=mean([spec_coefs(alphaRange)]); %8-12 Hz
    
    beta_1=mean([spec_coefs(betaRange1)]); %12-16 Hz
    beta_2=mean([spec_coefs(betaRange2)]); %16-26 Hz
    beta=mean([spec_coefs(betaRange)]); %12-26 Hz
    
    gamma_1=mean([spec_coefs(gammaRange1)]); %26-59 Hz-9
    gamma_2=mean([spec_coefs(gammaRange2)]); %59-125 Hz-10
    gamma=mean([spec_coefs(gammaRange)]); %26-125 Hz-11
    
    high_freq=mean([spec_coefs(highRange)]); %48-125 Hz
    all_freq=mean([spec_coefs(allRange)]); %0-124 Hz
    
    msp=[delta theta alpha_1 alpha_2 alpha beta_1 beta_2 beta gamma_1 gamma_2 gamma high_freq all_freq];
    msp1=msp(1:(length(msp)-1));
    %normalized spectral power (nsp)
    
    nsp=msp1/maxSpectralCoef;
    
    %power ratios
    ratio_1=nsp(2)/nsp(8); 
    ratio_2=nsp(2)/nsp(5);
    ratio_3=nsp(5)/nsp(8);
    ratio_4=nsp(1)/nsp(2);
    ratio_5=nsp(5)/nsp(1);
    ratio_6=nsp(8)/nsp(1);
    ratio_7=nsp(6)/nsp(5);
    ratio_8=nsp(7)/nsp(5);
    ratio_9=nsp(6)/nsp(7);
    power_ratios=[ratio_1 ratio_2 ratio_3 ratio_4 ratio_5 ratio_6 ratio_7 ratio_8 ratio_9];
    
    spectral_coefs=[msp nsp power_ratios];
    spectral_coefs=prototype_cleanup(spectral_coefs);
    specCo=prototype_cleanup(spectral_coefs);
    end