% test script: plot freq vs amplitude, 20 sec classification, test script
% 1000 atoms, 1000 scale freqs, in 20 s window
% histogram of ws amplitudes, each window, hist(x), fix bin range, two
% return arguments to hist, gives counts and positions of the bins.

%can do for each window, counts can be added. Overall distribution of
%amplitudes of atoms over all windows. plot as bar.

%% initialize variables
clear; clc; close;

subnum=1;
subs=8;
for subnum=1:subs;
    scales1=[.125 .25 .5];
    %scales1=[.25 .5 1 1.5 2 2.5];
    %scales1=[.5 1 1.5 2 2.5];
    %scales1=[.5 1 2.5];
    %bounds=[8 16];
    bounds=[10 26];
    atoms=200;
    jj=atoms;
    values=200;
    windowTime=4;
    
    %% load data
    
    filename=['excerpt' num2str(subnum) '.set'];
    clc;
    EEG = pop_loadset(filename);
    
    EEG=pop_resample(EEG,128);
    expertname=['expert_events' num2str(subnum) '.mat'];
    
    load(expertname);
    
    if subnum>6
        
        channel_index = 3;
        
    else
        channel_index=1;
        
    end
    
    
    bounds=sort(bounds,'ascend');
    
    EEG = removeTrend(EEG); clc;
    EEG = fastPreproc(EEG); clc;
    EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;
    
    %% binary rating vector
    
    rating=zeros(1,size(EEG.data,2));
    eventnumbers=size(expert_events,1);
    eventstart=zeros(1,eventnumbers);
    eventdur=zeros(1,eventnumbers);
    sampleStart=zeros(1,eventnumbers);
    sampleEnd=zeros(1,eventnumbers);
    
    %sampleTEnd=zeros(1,eventnumbers);
    
    lengthSec=windowTime;
    
    for u=1:eventnumbers;
        
        eventstart(u)=expert_events{u, 2};
        eventdur(u)=expert_events{u, 3};
        sampleStart(u)=ceil(EEG.srate*eventstart(u));
        %    sampleEnd(u)=sampleStart(u)+ceil(lengthSec*EEG.srate);
        sampleEnd(u)=ceil(EEG.srate*eventdur(u));
        rating(sampleStart(u):sampleEnd(u))=1;
    end
    
    
    
    %% unsupervised rating
    
    [ratingUnsupervised,coef,sigmaFreq] = spindleRatingUnsupervisedFreqFinder(EEG,channel_index,values,bounds,scales1,windowTime);
    
    [phi,~,~,accuracy,sensitivity,specificity,~,ppv,npv,f1,kappa]=vectorCorrection(ratingUnsupervised,rating);
    precision2=ppv;
    recall2=sensitivity;
    beta1 = 2;
    f1 = prototype_cleanup((1 + beta1^2).*(precision2.*recall2)./((beta1^2.*precision2) + recall2));
    
    
    x=[atoms; phi; sensitivity; specificity; ppv; npv; f1; accuracy; kappa];
    c1.rating=rating;
    c1.unsupervised=ratingUnsupervised;
    c1.coef=coef;
    output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1,accuracy,f1,kappa','Type','UnsupervisedMPAtomRating','Bounds',bounds,'Scale',scales1,'Key',sigmaFreq);
    
    filename1=['dream_score_ff_mp_' num2str(subnum) 'atoms' num2str(values) 'scalelength' num2str(length(scales1)) '.mat'];
    %save(filename1,'output');
     save(filename1,'output','-v7.3');
    save outputt1.mat output;
    save coeft1.mat coef;
    
end
