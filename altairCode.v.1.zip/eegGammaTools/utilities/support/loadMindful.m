
function [EEG,outputfilename,events] = loadMindful(number)

%--------------------------------------------------------------------------
% loadMindful

% Last updated: March 2016, J. LaRocco

% Details: Function loads mindfulness files from EDFs.

% Usage: eventTimes=loadMindful(filename,fs)

% Input:
%  number: subject and session number for subject/session (e.g., 26911011).

% Output:
%  EEG: EEGLAB format struct
%  outputfilename: filename of output, should save command be used.

%  Event number key: 

% Word (i.e., read a word printed in black): 1 
% Color Non-word (i.e., name the font color of 'XXXX'): 2 
% Color Word (i.e., name the font color of a color word): 3  
% Triggers to mark a response: Correct response: 7
% Incorrect response: 8 
% Incorrect response in which the subject responded with the read word rather than the font color: 9
% End of session: 0


%--------------------------------------------------------------------------



%number=26911011;
filename=['0' num2str(number) '.edf'];
%filename='026911011.edf';
EEG = medOpenRawTruncate(filename);

EEG.filepath=pwd;
EEG.filename=['0' num2str(number) '.set'];

filename2=['0' num2str(number) '_Events_.edf_Events.csv'];
%filename2='026911011_Events_.edf_Events.csv';
eventTimes=meditationCSVLoad(filename2,EEG.srate);

csvendpoint=eventTimes(2,end);

eegendpoint=length(EEG.data);

if csvendpoint < eegendpoint

synchdata=EEG.data(:,1:csvendpoint);
EEG.data=synchdata;
EEG.pnts=csvendpoint;
end;


[~,events]=size(eventTimes);


%i=1;


eventinfo=[];

event=struct('type',[],'latency',[],'duration',[],'urevent',[],'eventdescription',eventinfo);

for i=1:events;
    
    
    
switch eventTimes(3,i)
    case 1
        eventdescription='Stimulus: Word (i.e., read a word printed in black)';
    case 2
        eventdescription='Stimulus: Color Non-word (i.e., name the font color of XXXX)';
    case 3
       eventdescription='Stimulus: Color Word (i.e., name the font color of a color word)';
    case 7
        eventdescription='Response: Correct response';
    case 8
       eventdescription='Response: Incorrect response';
    case 9
       eventdescription='Response: Incorrect response in which the subject responded with the read word rather than the font color';
    case 0
        eventdescription='End of session';
    otherwise
        eventdescription='Other value';
end
    
eventinfo{i}=eventdescription;

event(i).type=eventTimes(3,i);
event(i).latency=eventTimes(2,i);
event(i).duration=1;
event(i).urevent=i;
event(i).eventdescription=eventinfo;

end

EEG.eventdescription=eventinfo;



EEG.event=event;

EEG.urevent=event;


%EEG = eeg_checkset(EEG);
outputfilename=['0' num2str(number) '.set'];
%save(outputfilename);
%events={1,2,3};
%limits=[-1 1];
%[EEG, indices, com] = pop_epoch( EEG, events, limits);
end
