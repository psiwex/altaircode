function EEG = soarPreproc(EEG,bnds)
% Extract the EEG
%
%  Parameters:
%     filename  EEGLAB EEG structure

%   Output:
%     EEG     EEGLAB EEG structure with the output
%
%   Written by:  John LaRocco, Feb 2016
%
% Assumes:  SOAR preprocessing for rough EEG. 

%%Baseline Removal
x=EEG.data;
fs=EEG.srate;
[chans,~]=size(x);

lbound=ceil(bnds(1));
ubound=floor(bnds(2));
f=lbound:1:ubound;
t=((-3*fs):1:(3*fs))';
%f=8:1:18;
s=10*ones(1,length(f));
gabors = exp(-pi*(t.^2)*s.^(-2)).*cos(2*pi*t*f./fs);

for i=1:chans;
    x1=mean(x(i,:));
    xx=x(i,:)-x1;
%[ws,yhat] = temporalMP(prototype_cleanup(xx'),gabors,false,20); clc;
    

    x(i,:)=prototype_cleanup(xx);
end
x=smoothdata(x);
x=x/max(max((x)));


%x=smoothdata(x);
EEG.data=x;
end
