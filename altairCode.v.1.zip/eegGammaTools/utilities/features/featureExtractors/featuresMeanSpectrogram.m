function [Pxx,power,h,y,f,t]=featuresMeanSpectrogram(segments,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESMEANSPECTROGRAM

% Last updated: April 2016, J. LaRocco

% Details: Feature extraction method, taking data from spectrogram.

% Usage: [Pxx,power]=featuresMeanSprectrogram(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx is a vector of the spectral features.
% power: matrix of raw power spectrums.
% h: image data
% f: frequency scale
% t: time scale
% y: outside
%--------------------------------------------------------------------------


%% Initializing
Pxx=[];
power=[];
[coef,inst]=size(segments);

Pxx=zeros(34,inst);
x=mean(segments');
%for i=1:1:inst
    
    %x=segments(:,i);
    
    %    pv=stftham(segments(:,i)',fs);
    
    [y,f,t,pv]=spectrogram(x,ceil(fs/4),ceil(fs/6),ceil(fs/4),fs);
    %p=10*abs(log10(p));
    
    h=spectrogram(x,ceil(fs/4),ceil(fs/6),ceil(fs/4),fs,'yaxis');
%    T = 0:0.001:2;
%X = chirp(T,0,1,150);
%[S,F,T,P] = spectrogram(X,256,250,256,1E3);
%surf(T,F,10*log10(P),'edgecolor','none')
    
    
    spec_coefs=pow2db(abs(pv));
    
    
    if i==1
        power=zeros(length(spec_coefs),inst);
    end
    
    power=spec_coefs;
    maxSpectralCoef=max(spec_coefs);
    
    
    Pxx=prototype_cleanup(featureSpecAdjust(spec_coefs,fs));
    
    
    % %

%
%
% end




end