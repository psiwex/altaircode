function [features] = stftGammaEEGFeatures(filename,period,events)
%John LaRocco

%--------------------------------------------------------------------------
% STFTGAMMAEEGFEATURES

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs gamma feature extraction using STFT method,
% and stores a struct, while also saving the files at different phases.

% Usage: [pf1,pf2,pv1,pv2,power1,power2] = stftGammaEEGFeatures(filename,period,events)

% Input:
%  filename: Name of file as text string. 
%  period: a matrix in brackets of time (s) to keep before (negative #) and after (positive #) event (e.g., [-1 1])
%  events: a cell of event labels to epoch (e.g., events={'StandardToneOn','DeviantToneOn'})

% Output:
% features: a struct of the final features and meta-data

%--------------------------------------------------------------------------

%%Preprocessing
%% Where the file is loaded and preprocessed.

EEG = pop_loadset(filename);
EEG = basePreprocessingWithBaselineAndBLASST(EEG); clc;

%fileout=['preprocessed_' filename '.set'];
%save(fileout,'EEG');

%     events={'StandardToneOn','DeviantToneOn'};
%     period=[-1 1];

%%Epoching
%% Where time segments related to the features are extracted.
[OUTEEG,indices] = pop_epoch(EEG, events, period);

%fileout=['blasst_epochs_' filename];
%save(fileout,'OUTEEG');
fs=OUTEEG.srate;
prelate=ceil(fs*abs(period(1)));

%% Feature Extraction
%% Where features are extracted from EEG data.
x=OUTEEG.data;
clear OUTEEG;

[pf1,pf2,pv1,pv2,power1,power2] = stftGammaFeatures(reordered,prelate,fs);
%[data,labels,x,t]=dataFormat(pf1,pf2);
%% Final export
%% Where data is exported in a struct.
features=struct('source_file',filename,'epoch_size',period,'fs',fs,'event_labels',events,'event_numbers',indices,'pre_stimulus_features',pf1,'post_stimulus_features',pf2,'preprocessing','BLASST, baseline removal','feature_extraction','STFT','featuretype','low gamma, high gamma, and power ratio for each channel');
%   files=['features_from_' filename];
%save(files,'features');

end