function [Pxx,power]=featuresMP(segments,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESMP

% Last updated: Feb 2016, J. LaRocco

% Details: Feature extraction method, using matching pursuit.

% Usage: [Pxx,power]=featuresMP(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx are the spectral features.
% power: matrix of raw power spectrums.
%

%--------------------------------------------------------------------------

[frames,chan]=size(segments);

dictionary1 = {{'db4',2},'dct','sin',{'sym4',1},{'sym4',4}};

mpdict = full(wmpdictionary(frames,'lstcpt',dictionary1));

Pxx=zeros(34,chan);
power=[];
for i=1:chan
    
    yith = wmpalg('OMP',full(segments(:,i)),mpdict);

    pv=pow2db(abs(prototype_cleanup(pwelch(yith,[],10,[],fs))));
    if i==1
        power=zeros(length(pv),chan);
    end
    power(:,i)=pv;  %#ok<AGROW>
   
    Pxx(:,i)=featureSpecOrganizer(pv);
    
end


end