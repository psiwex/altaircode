function [epoch] = epochFormat(ecog,infochannel,prelate,postlate)


%--------------------------------------------------------------------------
 % EPOCHFORMAT

 % Last updated: Jan 2016, J. LaRocco

 % Details: Epoch formatting of EEG data. A binary vectory of information,
 %          plus epoch start and end, are also needed. 
 % Usage: [epoch]=epochFormat(ecog,infochannel,prelate,postlate)
 
 % Input: 
 %  ecog: Matrix of EEG data. 
 %  infochannel: binary event vector with 1s where events start.
 %  prelate: pre-epoch period in samples.
 %  postlate: post-epoch period in samples. 
 
 % Output: 
 % epoch: epoch data stored as [channel x epoch x samples]. 

    
%--------------------------------------------------------------------------



%John LaRocco-December 2015

%The input includes the ecog data, the information channel depicting
%events, the start and end of the epoch (prelate and postlate), and it
%outputs the final epoch.

%% Epoch format


ecog_means=mean(ecog');
%ecogpower=[];
for i=1:length(ecog_means);

ecog(i,:)=ecog(i,:)-ecog_means(i);

%energy calc
%cc=ecog(i,:);
%E=sum(cc.^2);

%ecogpower(i)=E;


end

%clear ecog_hdr;
 % fs=1000;
  
  %load binaryevent.mat;
  
 % ecogevents=ecog_event(:,1:tone_session_end);
%   
%   %differences=ecogevents(3,:)-ecogevents(2,:);
%   differences=ecogevents(3,:);
%   
% %differences(differences<=0)=0;
% %differences(differences>1)=1;
% differences(differences==1)=2;
% differences=ecogevents(3,:)+differences;
% differences(differences==3)=2;
% 
% Cdifferences=differences;
% Cdifferences(Cdifferences==2)=1;


differences=infochannel;
  [start, ~, ~, events] = consecutive_ones(differences);
 
%replicate N1
  %prelate=100; postlate=300;
  epoch_start=start-prelate;
epoch_end=start+postlate;

% 
%  
 epoch_guide=[];
  for i=1:(events-1);
%   epochC(:,:,i)=differences(:,[epoch_start(i):epoch_end(i)]);
%if epoch_end(i)>length(differences)
 %   tu=abs(epoch_end(i)-differences);
  % ty=(differences(:,[epoch_start(i):length(differences)]));
   %epoch_guide(:,i)=[ty zeros(1,abs+1)];
   
%else
   epoch_guide(:,i)=(differences(:,[epoch_start(i):epoch_end(i)]));
%end
   %   
%   xc=differences(:,[epoch_start(i):epoch_end(i)]);
%  
%  lot=find(ismember(xc,[2 1]));
%  
  end
%  
 
 %here is where I'd get rid of any post-irregular normal stimulus
 %now, discounting first 3 trials. Since both seem to be idential,
 %shifting all back to standard binary. 
 le=length(epoch_guide);
 
 epoch_guide=epoch_guide(4:le); 
 %le=length(epoch_guide);
% epoch_guide(epoch_guide==2)=1;
epoch=[];


  for j=4:(events-1);
  epoch(:,:,j)=ecog(:,[epoch_start(j):epoch_end(j)]);
  
  end
  %[pv1,pv2] = epochrejecter(epoch,prelate);
  
end