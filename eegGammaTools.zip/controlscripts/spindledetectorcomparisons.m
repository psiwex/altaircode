%SDARtestbed
clear; clc;
filename='data/driving-data1.set';
load data/subject1010v2;
channel_index = [25:26];
values=[100 500:500:5000 10000 15000];
bounds=[6 18];
EEG = pop_loadset(filename);
[output0]=spindledetectorSDAR(EEG,channel_index,expert_events);
[output1]=spindledetectorBaselineReconstruction(EEG,channel_index,expert_events,values);
[output2]=spindledetectorWholeDictionary(EEG,channel_index,expert_events,values);
[output3]=spindledetectorRestrictedDictionary(EEG,channel_index,expert_events,values,bounds);
[output4]=spindledetectorBandpassFilter(EEG,channel_index,expert_events,values,bounds);




