function [EEG] = basePreprocessingWithBaselineAndBLASST(EEG)
%John LaRocco


%--------------------------------------------------------------------------
% basePreprocessingWithBaselineAndBLASST

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs preprocessing with baseline removal, BLASST for line noise, and detrending. 

% Usage: [EEG] = basePreprocessingWithBaselineAndBLASST(EEG)

% Input:
%  EEG: a struct of EEG data. 

% Output:
% EEG: a struct of final EEG data. 

%--------------------------------------------------------------------------

%%Preprocessing
%% Where the file is preprocessed.     
    EEG = removeTrend(EEG); clc;   
    EEG = medPreproc(EEG); clc;
    EEG = eeg_checkset(EEG); clc;
    
    
end