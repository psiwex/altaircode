clear;
clc;
tic;

bnds=[.1,40];
chanPercent=[];

fName='OSU-00001-04B-01-ERN.bdf';
subst='.bdf';

dirName = 'C:\Users\John\Documents\MATLAB\soarData\';
[sub] = subdir(dirName);

metaData=struct2table(sub);
fileList=metaData.name;
ii=fileList(1);
for ij=1:length(fileList)
ij
    ii=fileList(ij);
fName=ii{1};
tf = endsWith(fName,subst);
if tf ~= (0)
    try

    [EEG, command] = pop_readbdf(fName); 
snr0 = snrCompare(EEG.data,bnds,EEG.srate);
EEG = pop_resample(EEG,round(EEG.srate/4));
EEG= basePreprocessingSoar(EEG,bnds);
snr1 = snrCompare(EEG.data,bnds,EEG.srate);
chanPer=snr1/snr0;
catch
chanPer=1;
    end
end
chanPercent=[chanPercent; chanPer];

save('soarSnrResample3.mat','chanPercent');

end
finalMean=mean(chanPercent);
truPer=chanPercent(find(chanPercent~=1));
trueMean=mean(truPer);

toc;