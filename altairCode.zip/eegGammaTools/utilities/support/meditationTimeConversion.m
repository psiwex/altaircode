function timeSec=meditationTimeConversion(x1)

%--------------------------------------------------------------------------
% meditationTimeConversion

% Last updated: March 2016, J. LaRocco

% Details: Function loads a string with a timestamp formatted as
% "hour:minute:second:millisecond" and converts to seconds.

% Usage: timeSec=meditationTimeConversion(x1)

% Input:
%  x1: String with format "hour:minute:second:millisecond," separated by colons.

% Output:
% timeSec: time in seconds of time from string.

%--------------------------------------------------------------------------




x3=str2num(strrep(x1,':',';'));
startHour=x3(1);
startMin=x3(2);
startSec=x3(3);
startMS=x3(4);

timeSec=3600*startHour+60*startMin+startSec+(startMS./1000);


end