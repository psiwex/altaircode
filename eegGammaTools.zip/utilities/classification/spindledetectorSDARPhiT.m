function  [output]=spindledetectorSDARPhiT(EEG,channel_index,expert_events,bar)

%clear; close; clc;

%%DISCOUNTED AUTOREGRESSIVE BASELINE SCENARIO

%--------------------------------------------------------------------------
% SPINDLEDETECTORSDARROC

% Last updated: May 2016, J. LaRocco

% Details: Spindle detection system using discounted autoregressive (DAR) reconstruction.

% Usage:
% [output]=spindledetectorSDARROC(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  bar: threshold value (integer from 1 to 100)

% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------



%% reconstruct signal

order = 2;

for i = 1 : length(channel_index)
    
    
    [mu(i,:), sigma(i,:), loss(i,:), A(i,1:order,:)] = SDARv3(EEG.data(channel_index(i),:), order, .001, 1:100);
    
end


clear smoothed;
for k = 1 : length(channel_index)
    smoothed(k,:) = moving_average(loss(k,:), 5);
end



%% classification threshold
%% 1/3 is voting percent
thresholds=linspace(min(min(smoothed)),max(max(smoothed)),100);
[c1]=compareThresholdPhiM(EEG, expert_events, smoothed, thresholds(bar));

%% calculate hit rate
precision2=c1.agreement/(c1.agreement+c1.falsePositive);
recall2=c1.agreement/(c1.agreement+c1.falseNegative);
sensitivity2=c1.agreement/(c1.agreement+c1.falseNegative);
specificity2=c1.nullAgreement/(c1.nullAgreement+c1.falsePositive);


tp=(c1.agreement);
tn=(c1.nullAgreement);
fp=(c1.falsePositive);
fn=(c1.falseNegative);

beta1 = 2;
f1 = (1 + beta1^2).*(precision2.*recall2)./((beta1^2.*precision2) + recall2);

[phi,~,~,accuracy,sensitivity,specificity,~,ppv,npv]=correctOutputs(tp,tn,fp,fn);

x=[0; phi; sensitivity; specificity; ppv; npv; f1; accuracy];

output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1,accuracy','Type','BaselineSDARPhiM','TP',tp,'TN',tn,'FP',fp,'FN',fn);

end

