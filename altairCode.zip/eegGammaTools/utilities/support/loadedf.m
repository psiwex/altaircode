function [signal,Fs,Label,starttime,PhysDim,H1]=loadedf(FILENAME,CHAN,Records)
% signal=loadedf(FILENAME,CHANNEL,Records)
% Loads one CHANNEL of an EDF File (European Data Format for Biosignals) into MATLAB
% <A HREF="http://www.medfac.leidenuniv.nl/neurology/knf/kemp/edf.htm">About EDF</A> 
%
%  FILENAME
%  CHANNEL 	List of Channels; selected channels must have same sampling rate
%		1 default ; 
%		0 all channels with maximum sampling rate 
%  Records	List of Records  (default all)

%	Version 1.31
%	19.02.1998
%	Copyright (c) 1997, 1998 by Alois Schloegl
%	a.schloegl@ieee.org	

if nargin <3 Records=0; end;
if nargin <2 CHAN=1; end;
                      
fid=fopen(FILENAME,'r','ieee-le');
if fid<0 
	fprintf(2,['Error LOADEDF: File ' FILENAME ' not found\n']);  
	return;
end;

H1=setstr(fread(fid,256,'char')');	%
VER=H1(1:8);				%	8 Byte		Versionsnummer 
%if 0 fprintf(2,'LOADEDF: WARNING  Version EDF Format %i',ver); end;
pid = H1(9:88);			%	80 Byte		local patient identification
rid = H1(89:168);		%	80 Byte		local recording identification
startdate = H1(169:176);	%	8 Byte		
starttime = H1(177:184)	%	8 Byte		
headlen = str2num(H1(185:192));	%	8 Byte		Length of Header
% reserved = H1(193:236);	%	44 Byte		
nrec = str2num(H1(237:244));	%	8 Byte		# of data records
dur = str2num(H1(245:252));	%	8 Byte		# duration of data record in sec
ns = str2num(H1(253:256));	%	8 Byte		# of signals

Label = setstr(fread(fid,[16,ns],'char')');	%	
transducer = setstr(fread(fid,[80,ns],'char')');	%	
PhysDim = setstr(fread(fid,[8,ns],'char')');	%	

PHYSMIN=setstr(fread(fid,[8,ns],'char')');	%	
PHYSMAX=setstr(fread(fid,[8,ns],'char')');	%	

physmin=zeros(ns,1);
physmax=zeros(ns,1);
for k=1:ns,
	tmp=str2num(PHYSMIN(k,:));
	if isempty(tmp) physmin(k)=0;	%	
	else physmin(k)=tmp; end;	%	

	tmp=str2num(PHYSMAX(k,:));
	if isempty(tmp) physmax(k)=-1;	%	
	else physmax(k)=tmp; end;	%	
end;

digmin = str2num(setstr(fread(fid,[8,ns],'char')'));	%	
digmax = str2num(setstr(fread(fid,[8,ns],'char')'));	%	
prefilt= setstr(fread(fid,[80,ns],'char')');	%	
SPR = fread(fid,[8,ns],'char')';	%	samples per data record
spr = str2num(setstr(SPR));	%	samples per data record

%fread(fid,[32,ns],'char')';	%	reserved
fseek(fid,32*ns,0);

CAL = (physmax-physmin)./(digmax-digmin);
OFF = physmin-CAL.*digmin;
%OFF = physmax-CAL.*digmax;
tmp = find(CAL<0);
CAL(tmp) = ones(size(tmp));
OFF(tmp) = ones(size(tmp));

SAMPLERATE = spr/dur;

spb = sum(spr);	% Samples per Block
bi=[0; cumsum(spr)];

if nrec < 0
	tmp=ftell(fid);
    	fseek (fid,0,'eof');
    	POS=ftell(fid);
    	fseek (fid,tmp,'bof');
	nrec=(POS-tmp)/spb;
end;   

if Records==0 Records=1:nrec; end;
if CHAN==0 CHAN=find(spr==max(spr))'; end;

idx=[];
for k=CHAN, idx=[idx bi(k)+1:bi(k+1)]; end;
k=spr(CHAN(1));
S=zeros(k,length(CHAN));
signal=zeros(length(Records)*k,length(CHAN));

if any(spr(CHAN)~=spr(CHAN(1))) 
    fprintf(2,'Error LOADEDF: Channels %shave different SAMPLING RATES\n',sprintf('%i '));
else 
    Fs = spr(CHAN(1))/dur;                 
    
    for l=1:length(Records),
		NREC=Records(l)-1;
		if ((NREC<0) | (NREC>nrec)) error(['LOADEDF: invalid Record Number: ' int2str(NREC)]); end;
		fseek(fid,(headlen+NREC*spb*2),'bof');
		[s, count]=fread(fid,spb,'int16');
      S(:)=s(idx); 
      
      %%%%% Test on  Over- (Under-) Flow
		% V=sum([(S'>=digmax(CHAN,ones(k,1))) + (S'<=digmin(CHAN,ones(k,1)))])'==0;
         
      S=S.*CAL(CHAN,ones(k,1))'+OFF(CHAN,ones(k,1))';
      
      signal(k*(l-1)+(1:k),:)=S; %[S V];
   end;
end;

fclose(fid);
