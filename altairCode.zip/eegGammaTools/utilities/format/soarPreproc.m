function EEG = soarPreproc(EEG)
% Extract the EEG
%
%  Parameters:
%     filename  EEGLAB EEG structure

%   Output:
%     EEG     EEGLAB EEG structure with the output
%
%   Written by:  John LaRocco, Feb 2016
%
% Assumes:  SOAR preprocessing for rough EEG. 

%%Baseline Removal
x=EEG.data;
fs=EEG.srate;
[chans,~]=size(x);

for i=1:chans;
    x1=mean(x(i,:));
    xx=x(i,:)-x1;
    x(i,:)=xx;
end
x=smoothdata(x);
x=x/max(max((x)));
EEG.data=x;
end
