clear; close all;
clc;
tag=101;
pvalue=10;
%itt=30;
itt=1;
clear output;
%filename=['green.' num2str(tag) '.features.' num2str(pvalue) '.weaklearners.' num2str(itt) '.mat']; load(filename)
filename=['green.single.' num2str(tag) '.features.' num2str(pvalue) '.weaklearners.' num2str(1) '.mat']; load(filename)


%--------------------------------------------------------------------------
 % PLOTRESULTS

 % Last updated: Jan 2016, J. LaRocco

 % Details: A script to plot results, assuming they have standard results using PCA, ADEN, ADENZ, and PLS.  

 % Usage: plotResults
 
 % Input: 
 %  tag: how file is referred to. 
 %  maxpvalue: number of features results stored up to. 
 
 % Output: 
 % A figure. 

    
%--------------------------------------------------------------------------








%filename=['green.n.' num2str(tag) '.features.' num2str(pvalue) '.weaklearners.' num2str(itt) '.mat'];


%filename=['green.mix.' num2str(tag) '.features.' num2str(pvalue) '.partition.' num2str(itt) '.mat'];
load(filename);
% if s_pls_st_mean_phi==NaN;
% s_pls_st_mean_phi=0;
% else
 %s_pls_st_mean_phi=s_pls_st_mean_phi;    
     
 %end

xv=[s_aden_xv_mean_phi s_adenz_xv_mean_phi s_pca_xv_mean_phi s_pls_xv_mean_phi];
%st=[s_aden_st_mean_phi s_adenz_st_mean_phi s_pca_st_mean_phi s_pls_st_mean_phi];
%ab=[s_aden_ab_mean_phi s_adenz_ab_mean_phi s_pca_ab_mean_phi s_pls_ab_mean_phi];

%output(1:16,1)=[xv 0 0 st 0 0 ab]';
output(1:4,1)=xv;

maxpvalue=90;
mean_aden=[];
mean_adenz=[];
mean_pca=[];
mean_pls=[];

min_aden=[];
min_adenz=[];
min_pca=[];
min_pls=[];

max_aden=[];
max_adenz=[];
max_pca=[];
max_pls=[];
for pvalue=10:10:maxpvalue;
%tag=1;

%filename=['green.mix.' num2str(tag) '.features.' num2str(pvalue) '.partition.' num2str(5) '.mat'];
%filename=['green.n.' num2str(tag) '.features.' num2str(pvalue) '.weaklearners.' num2str(1) '.mat'];
%filename=['green.back.import.' num2str(tag) '.features.' num2str(pvalue) '.mat'];  
  filename=['green.single.' num2str(tag) '.features.' num2str(pvalue) '.weaklearners.' num2str(itt) '.mat'];
load(filename);

mean_pca=[mean_pca s_pca_xv_mean_phi];
mean_pls=[mean_pls s_pls_xv_mean_phi];
mean_aden=[mean_aden s_aden_xv_mean_phi];
mean_adenz=[mean_adenz s_adenz_xv_mean_phi];
totalmax=max(max([mean_pca mean_pls mean_aden mean_adenz]));
xv=[s_aden_xv_mean_phi s_adenz_xv_mean_phi s_pca_xv_mean_phi s_pls_xv_mean_phi];
output(1:4,(pvalue/10))=xv;

s_aden_xv_min_phi=min(s_xv_aden_mean_measures(1,:));
s_adenz_xv_min_phi=min(s_xv_adenz_mean_measures(1,:));
s_pca_xv_min_phi=min(s_xv_pca_mean_measures(1,:));
s_pls_xv_min_phi=min(s_xv_pls_mean_measures(1,:));

mins=[s_aden_xv_min_phi s_adenz_xv_min_phi s_pca_xv_min_phi s_pls_xv_min_phi];
output(7:10,(pvalue/10))=mins;

s_aden_xv_max_phi=max(s_xv_aden_mean_measures(1,:));
s_adenz_xv_max_phi=max(s_xv_adenz_mean_measures(1,:));
s_pca_xv_max_phi=max(s_xv_pca_mean_measures(1,:));
s_pls_xv_max_phi=max(s_xv_pls_mean_measures(1,:));

maxs=[s_aden_xv_max_phi s_adenz_xv_max_phi s_pca_xv_max_phi s_pls_xv_max_phi];
output(13:16,(pvalue/10))=maxs;


end;


maxfinder=totalmax+.05;
lims=maxpvalue;
pvalues=10:10:lims;


%maxfinder=max([max(pca_perf) max(pls_perf) max(aden_perf)]);
%figure(1);
subplot 221
%title('Phi coefficient of PCA-LDA with multiple features');
 
plot(pvalues,mean_pca);
ylim([0 maxfinder]); 
xlim([0 lims]);
xlabel('Number of Features: PCA-LDA');
ylabel('Phi Correlation');

% figure(2);
% title('Phi coefficient of PLS-LDA with multiple features');
subplot 222

plot(pvalues,mean_aden);
 ylim([0 maxfinder]); 
 xlim([0 lims]); 
 xlabel('Number of Features: ADEN-LDA');
 ylabel('Phi Correlation');
% 


subplot 223

plot(pvalues,mean_pls);
 ylim([0 maxfinder]); 
 xlim([0 lims]); 
 xlabel('Number of Features: PLS-LDA');
 ylabel('Phi Correlation');

 
subplot 224

plot(pvalues,mean_adenz);
 ylim([0 maxfinder]); 
 xlim([0 lims]); 
 xlabel('Number of Features: ADENZ-LDA');
 ylabel('Phi Correlation');
% 
