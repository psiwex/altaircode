function [Pxx,power]=featuresSpectrogram(segments,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESSPECTROGRAM

% Last updated: Feb 2016, J. LaRocco

% Details: Feature extraction method, taking data from spectrogram.

% Usage: [Pxx,power]=featuresSprectrogram(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx is a vector of the spectral features.
% power: matrix of raw power spectrums.

%--------------------------------------------------------------------------


%% Initializing
Pxx=[];
power=[];
[coef,inst]=size(segments);

Pxx=zeros(34,inst);

for i=1:1:inst
    
    %x=segments(:,i);
    
    %    pv=stftham(segments(:,i)',fs);
    
    f_i=[1:ceil(fs/2)];
    [y,f,t,pv]=spectrogram(segments(:,i),[],[],f_i,fs);
    %p=10*abs(log10(p));
    
    spec_coefs=pow2db(abs(pv));
    
    
    if i==1
        power=zeros(length(spec_coefs),inst);
    end
    
    power(:,i)=spec_coefs;
    maxSpectralCoef=max(spec_coefs);
    
    
    Pxx(:,i)=featureSpecAdjust(spec_coefs,fs);
    
    
    % %
end
%
%
% end




end