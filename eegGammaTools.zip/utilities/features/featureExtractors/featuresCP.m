function [Pxx,power]=featuresCP(segments,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESMP

% Last updated: Feb 2016, J. LaRocco

% Details: Feature extraction method, using change point.

% Usage: [Pxx,power]=featuresMP(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx are the spectral features.
% power: matrix of raw power spectrums.
%

%--------------------------------------------------------------------------

[frames,chan]=size(segments);
order1 = 2; order2 = 2;
learn_rate1 = .001;
learn_rate2 = .001;
Pxx=zeros(34,chan);
power=[];
for i=1:chan
    
    %yith = wmpalg('OMP',full(segments(:,i)),mpdict);
    [mu, sigma, loss, A] = SDAR(segments(:,i), order1, learn_rate1, 1:100, 'log');
    
    % smoothing the loss function to reduce effect of outliers
    smoothed1 = moving_average(loss, 20);
    
    % second pass of ChangeFinder
    [mu2, sigma2, loss2, A2] = SDAR(smoothed1, order2, learn_rate2, 1:100, 'quadratic');
    
    % smoothing again to reduce effect of outliers
    yith = moving_average(loss2, 20);
    
    
    pv=pow2db(abs(prototype_cleanup(pwelch(yith,[],10,[],fs))));
 
    
    
    if i==1
        power=zeros(length(pv),chan);
    end
    power(:,i)=pv;  %#ok<AGROW>
   
    Pxx(:,i)=featureSpecOrganizer(pv);
    
end


end