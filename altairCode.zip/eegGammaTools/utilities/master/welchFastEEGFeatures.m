function [features] = welchFastEEGFeatures(filename,period,events)
%John LaRocco


%--------------------------------------------------------------------------
% WELCHFASTEEGFEATURES

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs feature extraction using Welch method, 
% and stores a struct, without BLASST.

% Usage: [features] = welchFastEEGFeatures(filename,period,events)

% Input:
%  filename: Name of file as text string. 
%  period: a matrix in brackets of time (s) to keep before (negative #) and after (positive #) event (e.g., [-1 1])
%  events: a cell of event labels to epoch (e.g., events={'StandardToneOn','DeviantToneOn'})

% Output:
% features: a struct of the final features and meta-data

%--------------------------------------------------------------------------

%%Preprocessing
%% Where the file is loaded and preprocessed.

EEG = pop_loadset(filename);
EEG = basePreprocessingWithBaseline(EEG); clc;
%     events={'StandardToneOn','DeviantToneOn'};
%     period=[-1 1];

%%Epoching
%% Where time segments related to the features are extracted.
[OUTEEG,indices] = pop_epoch(EEG, events, period);
clear EEG;
%fileout=['blasst_epochs_' filename];
%save(fileout,'OUTEEG');
fs=OUTEEG.srate;
prelate=ceil(fs*abs(period(1)));

%% Feature Extraction
%% Where features are extracted from EEG data.
x=OUTEEG.data;
clear OUTEEG;


[pf1,pf2,pf3] = welchAllFeatures(x,prelate,fs);
%[data,labels,x,t]=dataFormat(pf1,pf2);
%% Final export
%% Where data is exported in a struct.
features=struct('source_file',filename,'epoch_size',period,'fs',fs,'event_labels',events,'event_numbers',indices,'pre_stimulus_features',pf1,'post_stimulus_features',pf2,'whole_epoch_features',pf3,'preprocessing','Bandpass filtering, baseline removal','feature_extraction','PWelch','featuretype','spectral features for each channel: delta 0-4 Hz, theta 4-8 Hz, alpha_1 8-10 Hz, alpha_2 10-12 Hz, alpha 8-12 Hz, beta_1 12-16 Hz, beta_2 16-26 Hz, beta 12-26 Hz, gamma_1 26-60 Hz, gamma_2 60-125 Hz, gamma 26-125 Hz, high_freq 47-125 Hz, all_freq 0-125 Hz, normalized power, 9 power ratios.');
%    files=['features_from_' filename];
% save(files,'features');

end