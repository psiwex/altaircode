Dependencies for ChangeFinder:

1. TSA - this provides the routines for estimating the initial parameters for the SDAR model. 
   The toolbox uses arfit2 to fit the initial AR model.

2. moving_average.m - This is a function downloaded from the MATLAB FEX that provides a one-step 
   moving-average of a signal. 