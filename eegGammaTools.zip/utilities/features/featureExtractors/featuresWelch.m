function [Pxx,power]=featuresWelch(segments,fs)

%--------------------------------------------------------------------------
% FEATURESWELCH

% Last updated: Nov 2023, J. LaRocco

% Details: Feature extraction method, taking data from multiple periodograms using Welch method.

% Usage: [y,power]=featuresWelch(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx is a matrix of the spectral features.
% power: matrix of raw power spectrums.

%--------------------------------------------------------------------------

power=[];

Pxx=[];

[coef,inst]=size(segments);

Pxx=zeros(36,inst);

for i=1:1:inst;

    pv=(pwelch(segments(:,i),[],10,[],fs));
    pcti=prctile(segments(:,i),99.95);
    spec_coefs=pow2db(abs(pv));
    
    if i==1
        power=zeros(length(spec_coefs),inst);
    end
    
    power(:,i)=spec_coefs;
    outFeat=[];
    outFeat=[featureSpecOrganizer(spec_coefs) mean(segments(:,i)) prototype_cleanup(pcti)];
    
    Pxx(:,i)=outFeat;
end


end