function [h,c1f,c2f] = alphaVarPlot(u,MaxFreq1,MaxFreq2)

%--------------------------------------------------------------------------
% alphaVarPlot

% Last updated: August 2016, J. LaRocco

% Details: Plot alpha variability sets

% Usage:
% [h,c1f,c2f] = alphaVarPlot(u,MaxFreq1,MaxFreq2);

% Input:
%  u: channel to use
%  MaxFreq1: one dataset to compare
%  MaxFreq2: other dataset to compare

% Output:
%  h: Output figure.
%  c1f: Mean for one channel. 
%  c2f: Mean for same channel in other category


%--------------------------------------------------------------------------


%sites = {'F3','Fz','F4','C3','Cz','C4','P3','Pz','P4','O1','Oz','O2'};

        h=figure; 
        plot(MaxFreq1(u,:));
        
        hold on;
        plot(MaxFreq2(u,:),'r');
        hold off;
        xlabel('Time (smoothed by 0.5 s window with 50% overlap)')
        ylabel('Frequency (Hz)')
        %imagesc(times,freqs,ersp);
        
        c1f=mean(MaxFreq1(u,:));
        c2f=mean(MaxFreq2(u,:));

end



