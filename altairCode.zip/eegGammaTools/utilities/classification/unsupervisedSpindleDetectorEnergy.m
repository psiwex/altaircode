function [rating,coef,sigmaFreq] = unsupervisedSpindleDetectorEnergy(EEG,channel_index,values,bounds,scales1)

%--------------------------------------------------------------------------
% unsupervisedSpindleDetectorEnergy

% Last updated: Sept 2016, J. LaRocco

% Details: Unsupervised MP-based spindle detector using energy of atoms to find events. 

% Usage:
% rating = unsupervisedSpindleDetectorEnergy(EEG,channel_index,values,bounds,scales1)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales1: scales of gabor atoms in a positive vector [0.5 1 2]

% Output:
%  rating: a binary rating vector (same length as number of samples) with 0 (non event) or 1 (event)
%  coef: A cell with other cells (one per channel) containing cells of each window's MP decomposition MP atom coefficients
%  sigmaFreq: key for scale and frequencies. First column is scale, second is frequency.

%--------------------------------------------------------------------------


scales=scales1;
%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));

%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));
coef=[];
channelcoef=[];
[channels,samples,~]=size(EEG.data);
%threshold=2*max(scales(end));
ratingVector=zeros(channels,samples);
windowLength=zeros(1,samples);
% 
% if channels==1;
%     channel_index=1;
% end
for jr=1:length(channel_index)


[~,~,sigmaFreq] = mpRDReconstruct(EEG,channel_index(jr)',values,bounds,scales);

 EEG.data=double(x)/max(max(x));


    x=squeeze(EEG.data(channel_index(jr),1:samples));
   
    [~,ws,~] = mpRDReconstruct(x,1,values,bounds,scales);
    clear EEG1;
    xtest=squeeze(ws);
    xtest=sum(xtest.^2)/length(xtest);
    channelcoef{1}=xtest;
    threshold=mean(mean(medium(xtest)));
    atomMask=(xtest>threshold);
    [row,column]=find(atomMask);
    
    for ii=1:length(column)
        %freq=sigmaFreq(column(ii),2);
        scale=sigmaFreq(column(ii),1);
        
        lb=ceil(row(ii)-EEG.srate*scale);
        ub=ceil(row(ii)+EEG.srate*scale);
        
        if lb<1
            lb=1;
        end
        
        if ub>length(windowLength);
            ub=length(windowLength);
        end
        windowLength(lb:ub)=1;
    
    end
    
    coef{jr}=channelcoef;
    ratingVector(jr,1:samples)=windowLength;
    
end



rating=ceil(mean(ratingVector));
rating(rating<.5)=0;
rating(rating>=.5)=1;

end