function [Pxx,power]=featuresDWT(epochs,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESDWT

% Last updated: Jan 2016, J. LaRocco

% Details: Feature extraction method, taking data from multiple periodograms using DWT method.

% Usage: [Pxx,power]=featuresDWT(segments,fs)

% Input:
%  epochs: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx are the spectral features.
% power: matrix of raw power spectrums.

%--------------------------------------------------------------------------
epochs=epochs';

Pxx=[];
power=[];
[coef,inst]=size(epochs);
Pxx=zeros(34,inst);
for i=1:1:inst
    
    yith=epochs(:,i);
    
    pn=sum(yith.^2)/length(yith);
    [A,B]=dwt(yith,'sym4');
    C=[A; B];
    pa=sum(C.^2)/length(C);
    C=C/pa;
    
    pv=prototype_cleanup(C);
    
    
    spec_coefs=pow2db(abs(pv));
    
    if i==1
        power=zeros(length(spec_coefs),inst);
    end
    
    power(:,i)=spec_coefs;
    
    Pxx(:,i)=featureSpecAdjust(spec_coefs,fs);
    
end

end