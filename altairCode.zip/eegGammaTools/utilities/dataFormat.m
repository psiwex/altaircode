function [data,labels,x,t]=dataFormat(pf1,pf2)

%--------------------------------------------------------------------------
 % DATAFORMAT

 % Last updated: Jan 2016, J. LaRocco

 % Details: Function reformats data so ICTOMI can handle it. The function merely
%           reformats data into cells and matrices (randomly reorganized). 

% Usage: [data,labels,x,t]=dataFormat(pf1,pf2);
% Inputs: 
 %  pf1: power features from pre-stim period.
 %  pf2: power features from post-stim period.

 % Outputs: 
%   x: matrix of spectral features x channels by epochs.
%   t: matrix of targets.
%   data: 2 cells of randomized data.
%   labels: 2 cells of randomized targets for data.
   
%--------------------------------------------------------------------------


x0=pf1; x1=pf2;
[a,b]=size(x0); [c,d]=size(x1);
t0=zeros(1,b);

t1=ones(1,d);

x=[x0 x1]; t=[t0 t1];
pp=length(t);
p=randperm(pp);
centerpoint=ceil(.5*pp);
startpoint=centerpoint+1;
x=prototype_cleanup(x);
x1=x(:,p); t1=t(p);

data=[];
labels=[];

data{1}=x1(:,1:centerpoint);

labels{1}=t1(:,1:centerpoint);

data{2}=x1(:,startpoint:pp);

labels{2}=t1(:,startpoint:pp);



end

