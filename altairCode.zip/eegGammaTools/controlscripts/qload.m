
clear;
clc;
%for i=1:length(file);
file={'Scalp_Test','Scalp_Retest'};

event{1}={'StandardToneOn','DeviantToneOn'};
event{2}={'StandardSpeechOn','DeviantSpeechOn'};

    period=[-1 1];

i=2;
    filename=[file{i} '.set'];
    events=event{i};
   %[features] = welchAllEEGFeaturesDebug(filename,period,events);
   
   

   %% PWELCH
 tic;
       [features] = welchFastEEGFeatures(filename,period,events);
       files=['welch_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
    toc;
    %% STFT
    tic;
        [features] = stftFastEEGFeatures(filename,period,events);
       files=['stft_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    toc;
     
    %% GMP
     
        [features] = gmpFastEEGFeatures(filename,period,events);
       files=['gmp_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
    %% DWT
     
        [features] = dwtFastEEGFeatures(filename,period,events);
       files=['dwt_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     

    
        %% MP
    
        [features] = mpFastEEGFeatures(filename,period,events);
       files=['mp_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
   
    
    %% Change point    
        [features] = cpFastEEGFeatures(filename,period,events);
       files=['cp_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;         
        %% MPS

        [features] = mpsFastEEGFeatures(filename,period,events);
       files=['mp_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    %% Changepoint+MP
   
        [features] = cpmpFastEEGFeatures(filename,period,events);
       files=['cpmp_fast_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
%end