
clear;
clc;
%for i=1:length(file);
file={'Scalp_Test','Scalp_Retest'};

event{1}={'StandardToneOn','DeviantToneOn'};
event{2}={'StandardSpeechOn','DeviantSpeechOn'};

    period=[-1 1];

i=2;
    filename=[file{i} '.set'];
    events=event{i};
   %[features] = welchAllEEGFeaturesDebug(filename,period,events);
   
   
    %% MP
        [features] = mpGammaEEGFeatures(filename,period,events);
       files=['mp_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
        [features] = mpAllEEGFeatures(filename,period,events);
       files=['mp_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
   
   %% PWELCH
    [features] = welchGammaEEGFeatures(filename,period,events);
       files=['welch_gamma_features_from_' filename '.mat'];
    save(files,'features');
    clear features;   
        [features] = welchAllEEGFeatures(filename,period,events);
       files=['welch_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
    
    %% STFT
    
      [features] = stftGammaEEGFeatures(filename,period,events);
       files=['stft_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
        [features] = stftAllEEGFeatures(filename,period,events);
       files=['stft_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
     
    %% GMP
            [features] = gmpGammaEEGFeatures(filename,period,events);
       files=['gmp_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
        [features] = gmpAllEEGFeatures(filename,period,events);
       files=['gmp_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
    %% DWT
         [features] = dwtGammaEEGFeatures(filename,period,events);
       files=['dwt_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
    
        [features] = dwtAllEEGFeatures(filename,period,events);
       files=['dwt_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
    %% Change point
     [features] = cpGammaEEGFeatures(filename,period,events);
       files=['cp_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    
        [features] = cpAllEEGFeatures(filename,period,events);
       files=['cp_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;         
        %% MPS
        [features] = mpsGammaEEGFeatures(filename,period,events);
       files=['mp_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
        [features] = mpsAllEEGFeatures(filename,period,events);
       files=['mp_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    %% Changepoint+MP
        [features] = cpmpGammaEEGFeatures(filename,period,events);
       files=['cpmp_gamma_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;   
        [features] = cpmpAllEEGFeatures(filename,period,events);
       files=['cpmp_all_features_from_' filename  '.mat'];
    save(files,'features');
    clear features;     
    
%end