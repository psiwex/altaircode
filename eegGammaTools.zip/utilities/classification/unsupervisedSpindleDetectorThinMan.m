function [rating,coef,sigmaFreq] = unsupervisedSpindleDetectorThinMan(EEG,channel_index,values,bounds,scales1)

%--------------------------------------------------------------------------
% unsupervisedSpindleDetectorThinMan

% Last updated: September 2016, J. LaRocco

% Details: Unsupervised MP-based event detector that calculates energy of Gaussian distribution frequency and scale, and uses them to mark events. 

% Usage:
% [rating,coef,sigmaFreq] = unsupervisedSpindleDetectorAtomSmasher(EEG,channel_index,values,bounds,scales1)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales1: scales of gabor atoms in a positive vector [0.5 1 2]

% Output:
%  rating: a binary rating vector (same length as number of samples) with 0 (non event) or 1 (event)
%  coef: A cell with other cells (one per channel) containing cells of each window's MP decomposition MP atom coefficients
%  sigmaFreq: key for scale and frequencies. First column is scale, second is frequency.

%--------------------------------------------------------------------------


scales=scales1;
%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));

%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));
coef=[];
channelcoef=[];
[channels,samples,~]=size(EEG.data);
%threshold=2*max(scales(end));
ratingVector=zeros(channels,samples);
% 
% if channels==1;
%     channel_index=1;
% end
for jr=1:length(channel_index)

%EEG.data=double(x)/max(max(x));
[~,ws,sigmaFreq] = mpRDReconstruct(EEG,channel_index(jr)',values,bounds,scales);

windowLength=zeros(1,samples);

    %EEG1=EEG;
    %x=squeeze(EEG.data(channel_index(jr),1:samples));
    
    xtest=squeeze(ws);
    channelcoef{1}=xtest;
    freqEnergy=sum(xtest.^2)/length(xtest);
    domPos=find(max(freqEnergy));
    domFreq=sigmaFreq(domPos,2);
    domScale=sigmaFreq(domPos,1);
    keeperFreqIndices=find(sigmaFreq(:,2)==domFreq);    
    keeperScaleIndices=find(sigmaFreq(:,1)==domScale);
    keeperIndices=sort(unique([keeperFreqIndices; keeperScaleIndices]),'ascend');
    xfind=xtest(:,keeperIndices);
    threshold=mean(mean(median(xfind)));
    
    
    
    
    atomMask=(xfind>threshold);
    [row,column]=find(atomMask);

    for ii=1:length(column)
        %freq(ii)=sigmaFreq(column(ii),2);
        %scale(ii)=sigmaFreq(column(ii),1);
        
        lb=ceil(row(ii)-EEG.srate*domScale);
        ub=ceil(row(ii)+EEG.srate*domScale);
        
        if lb<1
            lb=1;
        end
        
        if ub>length(windowLength);
            ub=length(windowLength);
        end
        windowLength(lb:ub)=1;
    
    end
    
    coef{jr}=channelcoef;
    ratingVector(jr,1:samples)=windowLength;
 

end
rating=ceil(mean(ratingVector));
rating(rating<.5)=0;
rating(rating>=.5)=1;

end