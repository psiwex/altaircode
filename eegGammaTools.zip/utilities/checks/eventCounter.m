
function [start1,end1,count,num_strings] = eventCounter(vector)



t = diff([0 vector 0]);
start1 = find(t == 1);
end1 = find(t == -1);
count = end1 - start1;
end1 = end1 -1;
num_strings=length(count); 

end