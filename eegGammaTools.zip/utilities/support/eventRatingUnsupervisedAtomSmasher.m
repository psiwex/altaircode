function [rating,coef,sigmaFreq] = eventRatingUnsupervisedAtomSmasher(EEG,channel_index,values,bounds,scales1,windowTime)

%--------------------------------------------------------------------------
% spindleRatingUnsupervised

% TSANAS TABLE AND CODE COMPARISON FOR TABLE 4

% Last updated: September 2016, J. LaRocco

% Details: Unsupervised MP-based event detector that calculates energy of dominant frequency and scale, and uses them to mark events. 

% Usage:
% [rating,coef,sigmaFreq] = eventRatingUnsupervisedAtomSmasher(EEG,channel_index,values,bounds,scales1,windowTime)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales1: scales of gabor atoms in a positive vector [0.5 1 2]
%  windowTime: multiple of how many times sampling frequency for window length (scalar, positive integer)

% Output:
%  rating: a binary rating vector (same length as number of samples) with 0 (non event) or 1 (event)
%  coef: A cell with other cells (one per channel) containing cells of each window's MP decomposition MP atom coefficients
%  sigmaFreq: key for scale and frequencies. First column is scale, second is frequency.

%--------------------------------------------------------------------------


scales=scales1;
%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));

%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));
coef=[];
channelcoef=[];
[channels,samples,~]=size(EEG.data);
%threshold=2*max(scales(end));
ratingVector=zeros(channels,samples);
% 
% if channels==1;
%     channel_index=1;
% end
for jr=1:length(channel_index)


[~,~,sigmaFreq] = mpRDReconstruct(EEG,channel_index(jr)',values,bounds,scales);

eeg_window=windowTime*EEG.srate;
eeg_high_bounds=zeros(1,samples);
eeg_low_bounds=zeros(1,samples);

for k=1:samples;
    eeg_high_bounds(k)=eeg_window+(EEG.srate*(k-1));
    eeg_low_bounds(k)=1+(EEG.srate*(k-1));
end

terminal=find(eeg_high_bounds<samples);
eeg_low_bounds=eeg_low_bounds(1:terminal(end));
eeg_high_bounds=eeg_high_bounds(1:terminal(end));
totalWindows=(terminal(end)-1);

windowLength=zeros(1,length(eeg_low_bounds(1):eeg_high_bounds(1)));

for i=1:totalWindows;

    EEG1=EEG;
    x=squeeze(EEG.data(channel_index(jr),eeg_low_bounds(i):eeg_high_bounds(i)));
    EEG1.data=double(x)/max(max(x));
    [~,ws,~] = mpRDReconstruct(EEG1,1,values,bounds,scales);
    clear EEG1;
    xtest=squeeze(ws);
    channelcoef{i}=xtest;
    freqEnergy=sum(xtest.^2)/length(xtest);
    domPos=find(max(freqEnergy));
    domFreq=sigmaFreq(domPos,2);
    domScale=sigmaFreq(domPos,1);
    keeperFreqIndices=find(sigmaFreq(:,2)==domFreq);    
    keeperScaleIndices=find(sigmaFreq(:,1)==domScale);
    keeperIndices=sort(unique([keeperFreqIndices; keeperScaleIndices]),'ascend');
    xfind=xtest(:,keeperIndices);
    threshold=mean(mean(median(xfind)));
    atomMask=(xfind>threshold);
    [row,column]=find(atomMask);

    for ii=1:length(column)
        %freq(ii)=sigmaFreq(column(ii),2);
        %scale(ii)=sigmaFreq(column(ii),1);
        
        lb=ceil(row(ii)-EEG.srate*domScale);
        ub=ceil(row(ii)+EEG.srate*domScale);
        
        if lb<1
            lb=1;
        end
        
        if ub>length(windowLength);
            ub=length(windowLength);
        end
        windowLength(lb:ub)=1;
    
    end
    
    coef{jr}=channelcoef;
    ratingVector(jr,eeg_low_bounds(i):eeg_high_bounds(i))=windowLength;
    
end


end
rating=ceil(mean(ratingVector));
rating(rating<.5)=0;
rating(rating>=.5)=1;

end