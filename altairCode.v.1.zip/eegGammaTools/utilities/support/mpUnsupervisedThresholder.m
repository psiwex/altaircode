function [bar,bars] = mpUnsupervisedThresholder(ws,channel_index,featurestouse)

%--------------------------------------------------------------------------
% mpUnsupervisedThresholder

% Last updated: August 2016, J. LaRocco

% Details: MP unsupervised thresholder.

% Usage:
% [bar,bars] = mpUnsupervisedThresholder(ws,channel_index)

% Input:
%  ws: a matrix of MP coefficients (matrix of channels by time by freq/scale)
%  channel_index: A vector of channels to limit analysis to.
%  featurestouse: Number of features to retain (scalar)

% Output:
%  bar: final threshold value.
%  bars: channel thresholds
%--------------------------------------------------------------------------

maxvalues=zeros(1,length(channel_index));
featurelist=zeros(featurestouse,length(channel_index));

for k = 1 : length(channel_index)
    x=squeeze(ws(channel_index(k),:,:));
    maxvalues(k)=max(max(abs(x)));
    x1=x/maxvalues(k);
    xx=reshape(x1,1,size(x,1)*size(x,2));
    xx=sort(xx,'descend');
    xx=xx(1,1:featurestouse);
    featurelist(:,k)=xx;
%   bars(k)=mean(xx(2:3));
end
bars=reshape(featurelist,1,featurestouse*k);
bars=sort(unique(bars),'ascend');
bar=mean(bars);


end



