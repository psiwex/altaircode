function [pf1,pf2,pf3,pv1,pv2,pv3,power1,power2,power3] = cpmpAllFeatures(epoch,prelate,fs)
%John LaRocco


%--------------------------------------------------------------------------
% CPMPALLFEATURES

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs feature extraction using GMP method.
% Input format for epochs must be:
% [channel x samples x epoch]

% Usage: [pf1,pf2,pf3,pv1,pv2,pv3,power1,power2,power3] = cpmpAllFeatures(epoch,prelate,fs)

% Input:
%  epoch: 3D Matrix of epoched data. [channel x samples x epoch]
%  prelate: samples before event to retain in epochs.
%  fs: sampling frequency

% Output:
% pf1: pre-stimulus matrix of features by epochs (2D).
% pf2: post-stimulus matrix of features by epochs (2D).
% pf3: matrix of features by epochs (2D).
% pv1: pre-stimulus power ratio cells.
% pv2: post-stimulus power ratio cells.
% pv3: whole epoch power ratio cells.
% power1: pre-stimulus features.
% power2: post-stimulus features.
% power3: entire epoch features.

%--------------------------------------------------------------------------



%% Artifact rejection: in case of one channelpf1=[];
pf2=[];
[channels,samples,epochnumbers]=size(epoch);

pf1=zeros(channels*34,epochnumbers);
pf2=zeros(channels*34,epochnumbers);
pf3=zeros(channels*34,epochnumbers);



order1 = 2; order2 = 2;
learn_rate1 = .001;
learn_rate2 = .001;

for id=1:epochnumbers;
    
    epochs=squeeze(epoch(:,:,id));
    
    %% Change point applied
    
    for i = 1 : channels
        
        
        % first pass of ChangeFinder
        
        [mu, sigma, loss, A] = SDAR(epochs(i,:), order1, learn_rate1, 1:100, 'log');
        
        % smoothing the loss function to reduce effect of outliers
        smoothed1 = moving_average(loss, 20);
        
        % second pass of ChangeFinder
        [mu2, sigma2, loss2, A2] = SDAR(smoothed1, order2, learn_rate2, 1:100, 'quadratic');
        
        % smoothing again to reduce effect of outliers
        smoothed2 = moving_average(loss2, 20);
        
        % set EEG1 data field to be the second stage smoothed signal
        epochs(i,:) = smoothed2;
        
    end
    
    
    
    
    
    %tu=[epochmeans(:,2:b) epochmeans(:,1)];
    %epochbipolar=(epochmeans-tu)';
    %epochs=epochmeans;
    clear epochmeans;
    
    
    %% Feature calculation
    %Now we find the features

    %[mp1,mw1,power1,pv1] = waveletgammaeeg(epochs1);
    %[mp1,mw1,power1,pv1] = gabormp(epochs1);
    epochs1=epochs(:,1:round(prelate));
    [pv1,power1]=featuresMP(epochs1',fs);
    %pv1=y';
    pv1=prototype_cleanup(pv1);
    %p11=unifyChannel(pv1);
    
    epochs2=epochs(:,round(prelate+1):end);
    [pv2,power2]=featuresMP(epochs2',fs);
    pv2=prototype_cleanup(pv2);
    %p21=unifyChannel(pv2);
    
       epochs3=epochs;
    [pv3,power3]=featuresMP(epochs3',fs);
    pv3=prototype_cleanup(pv3);
    
    
    pf1(:,id)=pv1(:);
    pf2(:,id)=pv2(:);
    pf2(:,id)=pv3(:);
end

end