function  [output]=spindledetectorSDAR(EEG,channel_index,expert_events)

%clear; close; clc;

%%DISCOUNTED AUTOREGRESSIVE BASELINE SCENARIO

%--------------------------------------------------------------------------
% SPINDLEDETECTORSDAR

% Last updated: May 2016, J. LaRocco

% Details: Spindle detection system using discounted autoregressive (DAR) reconstruction.

% Usage:
% [output]=spindledetectorBandpassFilter(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).

% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------



%% reconstruct signal

order = 2;

for i = 1 : length(channel_index)
    
    
    [mu(i,:), sigma(i,:), loss(i,:), A(i,1:order,:)] = SDARv3(EEG.data(channel_index(i),:), order, .001, 1:100);
    
end


clear smoothed;
for k = 1 : length(channel_index)
    smoothed(k,:) = moving_average(loss(k,:), 5);
end



%% classification threshold
%% 1/3 is voting percent
thresholds = [0.00001 .01:.01:1];
for K = 1 : length(thresholds)
    fprintf('K = %d\n', K);
    events = applyThreshold(smoothed, 128, thresholds(K), 1/3);
    new_events = combineEvents(events, .25, .25);
    
    
    [a,b,c] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
    
    sensitivity1(K) = c.agreement/(c.agreement + c.falseNegative);
    specificity1(K) = c.nullAgreement/(c.nullAgreement+c.falsePositive);
    precision1(K) = c.agreement/(c.agreement+c.falsePositive);
    recall1(K) = c.agreement/(c.agreement+c.falseNegative);
    
end

beta1 = 2;
f1 = (1 + beta1^2).*(precision1.*recall1)./((beta1^2.*precision1) + recall1);

[a,b] = max(f1);


%% calculating output metrics
events = applyThreshold(smoothed, 128, thresholds(b), 1/3);
new_events = combineEvents(events, .25, .25);

[a1,b1,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);

EEG.event = [];
temp1(size(expert_events,1)).type = [];
temp1(size(expert_events,1)).latency = [];

for i = 1 : size(expert_events, 1)
    temp1(i).type = 'start';
    temp1(i).latency = cell2mat(expert_events(i, 2))*EEG.srate;
    
end

for j = i+1 : 2*size(expert_events, 1)
    temp1(j).type = 'end';
    temp1(j).latency = cell2mat(expert_events(j-size(expert_events, 1), 3))*EEG.srate;
    
end
EEG.event = temp1;


%% calculate hit rate
temp10 = min(cell2mat(new_events(2:end,2))-cell2mat(new_events(1:end-1, 3)));


precision2=c1.agreement/(c1.agreement+c1.falsePositive);
recall2=c1.agreement/(c1.agreement+c1.falseNegative);
sensitivity2=c1.agreement/(c1.agreement+c1.falseNegative);
specificity2=c1.nullAgreement/(c1.nullAgreement+c1.falsePositive);


tp=c1.agreement;
tn=c1.nullAgreement;
fp=c1.falsePositive;
fn=c1.falseNegative;


Tp=[]; Tn=[]; Fp=[]; Fn=[];


Tp=[Tp; tp];
Tn=[Tn; tn];
Fp=[Fp; fp];
Fn=[Fn; fn];


[phi,roc,auc_roc,accuracy,sensitivity,specificity,acc2,ppv,npv]=correctOutputs(tp,tn,fp,fn);
f1=2*(ppv*npv)./(ppv+npv);
x(:,1)=[0; phi; sensitivity; specificity; ppv; npv; f1];

output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1','Type','BaselineSDARwithoutMP','TP',Tp,'TN',Tn,'FP',Fp,'FN',Fn);

end

