function [pf1,pf2,pf3,pv1,pv2,pv3,power1,power2,power3] = cpAllFeatures(epoch,prelate,fs)
%John LaRocco
%This will reject any epochs and then return spectral
%band features. You also need time pre-stimulus (prelate).


%--------------------------------------------------------------------------
% CPALLFEATURES

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs feature extraction using CP method.
% Input format for epochs must be:
% [channel x samples x epoch]

% Usage: [pf1,pf2,pf3,pv1,pv2,pv3,power1,power2,power3] = cpAllFeatures(epoch,prelate,fs)

% Input:
%  epoch: 3D Matrix of epoched data. [channel x samples x epoch]
%  prelate: samples before event to retain in epochs.
%  fs: sampling frequency

% Output:
% pf1: pre-stimulus matrix of features by epochs (2D).
% pf2: post-stimulus matrix of features by epochs (2D).
% pf3: matrix of features by epochs (2D).
% pv1: pre-stimulus power ratio cells.
% pv2: post-stimulus power ratio cells.
% pv3: whole epoch power ratio cells.
% power1: pre-stimulus features.
% power2: post-stimulus features.
% power3: entire epoch features.

%--------------------------------------------------------------------------



%% Artifact rejection: in case of one channel

[channels,samples,epochnumbers]=size(epoch);

pf1=zeros(channels*34,epochnumbers);
pf2=zeros(channels*34,epochnumbers);
pf3=zeros(channels*34,epochnumbers);

%epochkept=epoch2(keepers,:);
%preallocate channel
for id=1:epochnumbers
    
    epochs=squeeze(epoch(:,:,id));
    
    %%  Feature calculation
    %Now we find the features
    %epochs=epochs';
    epochs1=epochs(:,1:round(prelate));
    [pv1,power1]=featuresCP(epochs1',fs);
    %pv1=y';
    pv1=prototype_cleanup(pv1);
    %p11=unifyChannel(pv1);
    
    epochs2=epochs(:,round(prelate+1):end);
    [pv2,power2]=featuresCP(epochs2',fs);
    pv2=prototype_cleanup(pv2);
    %p21=unifyChannel(pv2);
    
       epochs3=epochs;
    [pv3,power3]=featuresCP(epochs3',fs);
    pv3=prototype_cleanup(pv3);
    
    
    pf1(:,id)=pv1(:);
    pf2(:,id)=pv2(:);
    pf3(:,id)=pv3(:);
end

end