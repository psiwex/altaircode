Plugin to import BDF (Biosemi 24-bit EDF files). The BIOSIG
plugin is recommended for importing BDF files and this plugin
should only be used in case the BIOSIG plugin encounter a 
problem

Versions:
1.2 - Fixed an issue with menu positioning
