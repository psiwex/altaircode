function [pf1,pf2,pv1,pv2,power1,power2] = welchGammaFeatures(epoch,prelate,fs)
%John LaRocco
%This will reject any epochs and then return upper gamma and lower gamma
%band features. You also need time pre-stimulus (prelate).



%--------------------------------------------------------------------------
% WELCHGAMMAFEATURES

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs gamma feature extraction using Welch method. 
% Input format for epochs must be:
% [channel x samples x epoch]

% Usage: [pf1,pf2,pv1,pv2,power1,power2] = welchGammaFeatures(epoch,prelate,fs)

% Input:
%  epoch: 3D Matrix of epoched data. [channel x samples x epoch]
%  prelate: samples before event to retain in epochs.
%  fs: sampling frequency

% Output:
% pf1: pre-stimulus matrix of features by epochs (2D).
% pf2: post-stimulus matrix of features by epochs (2D).
% pv1: pre-stimulus power ratio cells.
% pv2: post-stimulus power ratio cells.
% power1: pre-stimulus features.
% power2: post-stimulus features.

%--------------------------------------------------------------------------



%% Artifact rejection: in case of one channel
pf1=[];
pf2=[];
[jj,jk,jl]=size(epoch);

%epochkept=epoch2(keepers,:);

    for id=1:jl;
     clear epochkept;
 
    epochs=squeeze(epoch(:,:,id));
    
    
    %% Gamma feature calculation
    %Now we find the features
    %epochs=epochs';
    epochs1=epochs(:,1:round(prelate));
    %[mp1,mw1,power1,pv1] = waveletgammaeeg(epochs1);
    %[mp1,mw1,power1,pv1] = gabormp(epochs1);
    [y]=featuresWelch(epochs1',fs);
    y=y';
    power1=y(:,9:10);
    pv1=y(:,9)./ y(:,10);
    pv1=prototype_cleanup(pv1);
    %pvv1=pv1(:,1)+pv1(:,2);
    
    
    %pre-stimulus feature vector
    p1=[power1'; pv1']; p1=p1';
    p11=unifyChannel(p1);
    
    epochs2=epochs(:,round(prelate+1):length(epochs));
    %[mp2,mw2,power2,pv2] = gabormp(epochs2);
    [y]=featuresWelch(epochs2',fs);
    y=y';
    power2=y(:,9:10);
    pv2=y(:,9)./ y(:,10);
    pv2=prototype_cleanup(pv2);
    p2=[power2'; pv2'];
    p21=unifyChannel(p2);
    %p212=unifyChannel(p2');
    %pvv2=pv2(:,1)+pv2(:,2);
    %[p_anova,table_anova,stats_anova] = anovafor3(pv1,pv2,apv1,apv2);
    pf1(:,id)=p11;
    pf2(:,id)=p21;
    end

end