function  [output]=spindledetectorFatMan(EEG,channel_index,expert_events,values,bounds,scales1)

%--------------------------------------------------------------------------
% spindledetectorFatMan

% Last updated: September 2016, J. LaRocco

% Details: Spindle detection system using matching pursuit reconstruction
% with adaptive Gaussian thresholding.

% Usage:
% [output]=spindledetectorFatMan(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales: scales of gabor atoms in a positive vector [0.5 1 2]

% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------





%% Reconstruct signal


EEG = removeTrend(EEG); clc;
EEG = fastPreproc(EEG); clc;
EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;

[smoothed,ws,sigmaFreq] = mpRDReconstruct(EEG,channel_index,values,bounds,scales1);


x=ws(:);
x=abs(x);

GMModel = fitgmdist(x,2);

mu1=GMModel.mu(1);
mu2=GMModel.mu(2);

sigma=squeeze(GMModel.Sigma);
sigma1=sigma(1);
sigma2=sigma(2);

thresholds=abs(((sigma1*mu2)+(sigma2*mu1))/(sigma1+sigma2));



%% Apply threshold for classification

x=[];

atoms=values;
[c1]=compareThresholdMaxPhiVote(EEG, expert_events, smoothed, thresholds, channel_index);

%% calculate hit rate


tp=c1.agreement;
tn=c1.nullAgreement;
fp=c1.falsePositive;
fn=c1.falseNegative;
c1.coef=ws;
c1.sigmaFreq=sigmaFreq;
threshold=c1.threshold;

[phi,~,~,~,sensitivity,specificity,~,ppv,npv,f1,kappa]=correctOutputs(tp,tn,fp,fn);

x(:,1)=[atoms; phi; sensitivity; specificity; ppv; npv; f1; threshold; kappa];



output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1,threshold,kappa','Type','FatMan','Bounds',bounds,'TP',tp,'TN',tn,'FP',fp,'FN',fn);

end

