function X=stftham(x,fs)

% STFT Short Time Fourier Transform with Hamming window
% 
% 

%--------------------------------------------------------------------------
 % STFTHAM

 % Last updated: Feb 2016, J. LaRocco

 % Details: Short Time Fourier Transform with Hamming window.
 % Modified from code by Suraj Kamya: http://www.mathworks.com/matlabcentral/fileexchange/38035-stft--short-time-fourier-transform
 % modified by John LaRocco-Feb 2016
 
 % Usage: [X]=stftham(x,fs)
 
 % Input: 
 %  x: 1D signal data. 
 %  fs: sampling frequency.
 
 % Output: 
 % X: X is the transformed output, with length fs/2.

    
%--------------------------------------------------------------------------

%wl=125;
wl=ceil(fs/2);
%wl=length(x);
%disp('Qverloopingf of window is 50%');
%disp('1 Rectangular Window, 2 Hamming window,  3 Hanning window');
% window=input('Enter your choice');
L=length(x);
if L<wl
    z=wl-L;
    x=[x,zeros(1,z)];
end

 win=hamming(wl)'; 


L=length(x);
hop=ceil(wl/2);  % Hoop size of window
if hop<1
    hop=wl;
end
i=1;str=1; len=wl; X=[];
while (len<=L || i<2) 
    if i==1
    if  len>L   % If window size excceds the L of signal for 1st time
        z=len-L;
        x=[x,zeros(1,z)]; % padding zeros
        i=1+1;
    end
    x1=x(str:len);
    X=[X;fft(x1.*win)];  % Matrix multiplication
    str=str+hop; len=str+wl-1; % to make window overlapping
        end
end

X=mean(X);


end


        
