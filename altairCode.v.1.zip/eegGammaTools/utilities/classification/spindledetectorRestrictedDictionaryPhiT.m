function  [output]=spindledetectorRestrictedDictionaryPhiT(EEG,channel_index,expert_events,values,bounds,scales,bar)

%--------------------------------------------------------------------------
% SPINDLEDETECTORRESTRICTEDDICTIONARYROC

% Last updated: May 2016, J. LaRocco

% Details: Spindle detection system using matching pursuit reconstruction
% with a restricted dictionary.

% Usage:
% [output]=spindledetectorRestrictedDictionaryROC(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales: scales of gabor atoms in a positive vector [0.5 1 2]
%  bar: threshold value (integer from 1 to 100)


% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------





%% Reconstruct signal


EEG = removeTrend(EEG); clc;
EEG = fastPreproc(EEG); clc;
EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;

[smoothed] = mpRDReconstruct(EEG,channel_index,values,bounds,scales);


%% Apply threshold for classification

%thresholds = [0.00001 .01:.01:1];
thresholds=linspace(min(min(smoothed)),max(max(smoothed)),100);

atoms=values;

[c1]=compareThresholdPhiM(EEG, expert_events, smoothed, thresholds(bar));

%% calculate hit rate

precision2=c1.agreement/(c1.agreement+c1.falsePositive);
recall2=c1.agreement/(c1.agreement+c1.falseNegative);


tp=(c1.agreement);
tn=(c1.nullAgreement);
fp=(c1.falsePositive);
fn=(c1.falseNegative);
tt=(c1.totalTime);

beta1 = 2;
f1 = (1 + beta1^2).*(precision2.*recall2)./((beta1^2.*precision2) + recall2);

[phi,~,~,accuracy,sensitivity,specificity,~,ppv,npv]=correctOutputs(tp,tn,fp,fn);
x=[atoms; phi; sensitivity; specificity; ppv; npv; f1; accuracy];

output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1,accuracy','Type','RestrictedDictionaryPhiM','Bounds',bounds,'TP',tp,'TN',tn,'FP',fp,'FN',fn,'totalTime',tt);

end

