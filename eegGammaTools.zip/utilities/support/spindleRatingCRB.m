function [rating,coef,IAFreq,relPower] = spindleRatingCRB(EEG,channel_index,bounds,windowTime)

%--------------------------------------------------------------------------
% spindleRatingCRB

% Last updated: August 2016, J. LaRocco

% Details: Unsupervised CRB-based spindle detector, based on Goljahani paper.

% Usage:
% rating = spindleRatingCRB(EEG,channel_index,values,bounds,scales1,windowTime)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  windowTime: multiple of how many times sampling frequency for window length (scalar, positive integer)

% Output:
%  rating: a binary rating vector (same length as number of samples) with 0 (non event) or 1 (event)
%  coef: A cell with other cells (one per channel) containing cells of each window's MP decomposition MP atom coefficients
%  IAFreq: dominant frequencies for each window
%  relPower: relative power for each window

%--------------------------------------------------------------------------


%scales=linspace(scales1(1),scales1(end),ceil(values/length(bounds(1):bounds(end))));
coef=[];
channelcoef=[];
[channels,samples,~]=size(EEG.data);
%threshold=2*max(scales(end));
ratingVector=zeros(channels,samples);
%
% if channels==1;
for jr=1:length(channel_index)
    
    
    %[~,~,sigmaFreq] = mpRDReconstruct(EEG,channel_index(jr)',values,bounds,scales);
    
    eeg_window=windowTime*EEG.srate;
    eeg_high_bounds=zeros(1,samples);
    eeg_low_bounds=zeros(1,samples);
    
    for k=1:samples;
        eeg_high_bounds(k)=eeg_window+(EEG.srate*(k-1));
        eeg_low_bounds(k)=1+(EEG.srate*(k-1));
    end
    
    terminal=find(eeg_high_bounds<samples);
    eeg_low_bounds=eeg_low_bounds(1:terminal(end));
    eeg_high_bounds=eeg_high_bounds(1:terminal(end));
    totalWindows=(terminal(end)-1);
    
    windowLength=zeros(1,length(eeg_low_bounds(1):eeg_high_bounds(1)));
    relPower=zeros(1,totalWindows);
    IAFreq=zeros(1,totalWindows);
    for i=1:totalWindows;
        
        par.CRBpar.timeintervals.ref_int=[eeg_low_bounds(i) eeg_high_bounds(i)-EEG.srate];
        par.CRBpar.timeintervals.test_int=[(eeg_high_bounds(i)-EEG.srate+1) eeg_high_bounds(i)];
        
        %EEG1=EEG;
        %x=squeeze(EEG.data(channel_index(jr),eeg_low_bounds(i):eeg_high_bounds(i)));
        %EEG1.data=double(x)/max(max(x));
        par.CRB_dataindexes=channel_index(jr);
        %par.CRBpar.timeintervals.ref_int=[1 (windowTime-1)*EEG.srate];
        %par.CRBpar.timeintervals.test_int=[((windowTime-1)*EEG.srate+1) windowTime*EEG.srate];
        par.CRBfieldpar.includeavespectra=1;
        %par.CRBfieldpar.includestspectra=1;
        %par.savepar.mat=1;
        par.CRBfield=1;
        par.savepar.CRBfield=1;
        par.spectrapar.freq_lim=bounds;
        %par.algpar.alpha_interval=bounds;
        par.algpar.scan_interval=bounds;
        %par.savepar.matpar.filename= 'tmp';
        typeproc=1;
        EEG1 = pop_CRBanalysis( EEG, typeproc, par );
        
        iafreq=cell2mat(EEG1.CRB.results(2,2));
        IAFreq(i)=iafreq;
        %     f1=cell2mat(EEG1.CRB.results(2,6));
        %     f2=cell2mat(EEG1.CRB.results(2,7));
        %     range=.5*((iafreq-f1)+(f2-iafreq));
        %
        
        relPower(i)=cell2mat(EEG1.CRB.results(2,10));
        
        
        
        %[~,ws,~] = mpRDReconstruct(EEG1,1,values,bounds,scales);
        
        channelcoef{i}=EEG1.CRB;
        clear EEG1;
        %     xtest=squeeze(ws);
        %     atomMask=(xtest>threshold);
        %     [row,column]=find(atomMask);
        %
        %for ii=1:length(column)
        if i==1
            prevComp=0;
        else
            prevComp=relPower(i-1);
        end
        %freq=sigmaFreq(column(ii),2);
        %scale=sigmaFreq(column(ii),1);
        
        
        lb=((windowTime-1)*EEG.srate+1);
        ub=windowTime*EEG.srate;
        
        
        %lb=ceil(row(ii)-EEG.srate*scale);
        %ub=ceil(row(ii)+EEG.srate*scale);
        
        if lb<1
            lb=1;
        end
        
        if ub>length(windowLength);
            ub=length(windowLength);
        end
        if abs(relPower(i))>prevComp && i>1
            
            windowLength(lb:ub)=1;
        end
        
        % end
        
        coef{jr}=channelcoef;
        ratingVector(jr,eeg_low_bounds(i):eeg_high_bounds(i))=windowLength;
        
    end
    
    
end
rating=ceil(mean(ratingVector));
rating(rating<.5)=0;
rating(rating>=.5)=1;

%     channel_index=1;
% end
end