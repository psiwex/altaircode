function [EEG1] = baseSDAR(EEG)
%John LaRocco


%--------------------------------------------------------------------------
% baseSDAR

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs preprocessing with SDAR. 

% Usage: [EEG] = baseSDAR(EEG)

% Input:
%  EEG: a struct of EEG data. 

% Output:
% EEG: a struct of final EEG data. 

%--------------------------------------------------------------------------

%%Preprocessing
%% Where the file is preprocessed.     

order1 = 2; order2 = 2;
learn_rate1 = .001;
learn_rate2 = .001;

EEG1 = EEG;
EEG1.data = [];
[channels,samples]=size(EEG.data);
for i = 1 : channels
    
    % first pass of ChangeFinder
  [mu, sigma, loss, A] = SDAR(EEG.data(i,:), order1, learn_rate1, 1:100, 'log');
    
    % smoothing the loss function to reduce effect of outliers
    smoothed1 = moving_average(loss, 20);
    
    % second pass of ChangeFinder
    [mu2, sigma2, loss2, A2] = SDAR(smoothed1, order2, learn_rate2, 1:100, 'quadratic');
    
    % smoothing again to reduce effect of outliers
    smoothed2 = moving_average(loss2, 20);
    
    % set EEG1 data field to be the second stage smoothed signal
    EEG1.data(i,:) = smoothed2;
    
end

    
    
end