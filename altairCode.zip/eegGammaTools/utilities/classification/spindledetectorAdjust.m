function  [output]=spindledetectorAdjust(EEG,channel_index,expert_events,values,bounds,scales)

%%BANDPASS FILTER SIGNAL AND TAKE RECONSTRUCTION


%--------------------------------------------------------------------------
% SPINDLEDETECTORADJUST

% Last updated: May 2016, J. LaRocco

% Details: Spindle detection system using matching pursuit reconstruction
% with custom parameters.

% Usage:
% [output]=spindledetectorAdjust(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales: length of Gabor atoms (scalar, positive integer)

% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------


%% reconstruct signal

bounds=sort(bounds,'ascend');
lbound=bounds(1);
ubound=bounds(2);
f=lbound:.5:ubound;

fs=EEG.srate;
EEG = removeTrend(EEG); clc;
EEG = fastPreproc(EEG); clc;
EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;

deviationFactor = 3;  %Number of standard deviations for the support
srate = EEG.srate;
%scales = [0.5, 1, 2];
frequencies = lbound:ubound;
numberScales = length(scales);
numberFreq = length(frequencies);
numberGabors = numberFreq*numberScales;
sigmaFreq = zeros(numberGabors, 2);
k = 1;
for n = 1:numberScales
    for m = 1:numberFreq
        sigmaFreq(k, 1) = 0.5*scales(n);
        sigmaFreq(k, 2) = frequencies(m);
        k = k + 1;
    end
end

maxSD = max(scales)/2;

t = -deviationFactor*maxSD:1/srate:deviationFactor*maxSD;  % time in seconds

%% Create Gabors
gabors = zeros(length(t), numberGabors);
for k = 1:numberGabors
   factor = sigmaFreq(k, 1)*sqrt(2*pi);
   gabors(:, k) = exp(-.5*(t.^2)*sigmaFreq(k, 1).^(-2)).*cos(2*pi*t*sigmaFreq(k, 2))./factor;
end


clear smoothed;

ka=1;
x=[]; Tp=[]; Tn=[]; Fp=[]; Fn=[];
for ka=1:length(values);
    atoms=values(ka);
    clear smoothed;
    for k = 1 : length(channel_index)
        
        yith=EEG.data(channel_index(k),:);
        
        
        [ws,yhat] = temporalMP(prototype_cleanup(yith'),gabors,false,atoms); clc;
        
        smoothed(k,:) = yhat;
        
    end
    
    
    %% apply thresholds
    
    thresholds = [0.00001 .01:.01:1];
    for K = 1 : length(thresholds)
        
        events = applyThreshold(smoothed, 128, thresholds(K), 1/3);
        new_events = combineEvents(events, .25, .25);
        
        
        [a,b,c] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
        
        sensitivity1(K) = c.agreement/(c.agreement + c.falseNegative);
        specificity1(K) = c.nullAgreement/(c.nullAgreement+c.falsePositive);
        precision1(K) = c.agreement/(c.agreement+c.falsePositive);
        recall1(K) = c.agreement/(c.agreement+c.falseNegative);
        
    end
    %% calculate output measures
    
    beta1 = 2;
    f1 = (1 + beta1^2).*(precision1.*recall1)./((beta1^2.*precision1) + recall1);
    
    [a,b] = max(f1);
    
    
    events = applyThreshold(smoothed, 128, thresholds(b), 1/3);
    new_events = combineEvents(events, .25, .25);
    
    [a1,b1,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
    
    
    EEG.event = [];
    temp1(size(expert_events,1)).type = [];
    temp1(size(expert_events,1)).latency = [];
    
    for i = 1 : size(expert_events, 1)
        temp1(i).type = 'start';
        temp1(i).latency = cell2mat(expert_events(i, 2))*EEG.srate;
        
    end
    
    for j = i+1 : 2*size(expert_events, 1)
        temp1(j).type = 'end';
        temp1(j).latency = cell2mat(expert_events(j-size(expert_events, 1), 3))*EEG.srate;
        
    end
    EEG.event = temp1;
    
    
    %% calculate hit rate
    temp10 = min(cell2mat(new_events(2:end,2))-cell2mat(new_events(1:end-1, 3)));
    
    
    precision2=c1.agreement/(c1.agreement+c1.falsePositive);
    recall2=c1.agreement/(c1.agreement+c1.falseNegative);
    sensitivity2=c1.agreement/(c1.agreement+c1.falseNegative);
    specificity2=c1.nullAgreement/(c1.nullAgreement+c1.falsePositive);
    
    tp=c1.agreement;
    tn=c1.nullAgreement;
    fp=c1.falsePositive;
    fn=c1.falseNegative;
    
    Tp=[Tp; tp];
    Tn=[Tn; tn];
    Fp=[Fp; fp];
    Fn=[Fn; fn];
    
    
    
    [phi,roc,auc_roc,accuracy,sensitivity,specificity,acc2,ppv,npv]=correctOutputs(tp,tn,fp,fn);
    f1=2*(ppv*npv)./(ppv+npv);
    x(:,ka)=[atoms; phi; sensitivity; specificity; ppv; npv; f1];
    
end
output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1','Type','RestrictedDictionary','Bounds',bounds,'TP',tp,'TN',tn,'FP',fp,'FN',fn);

end

