function [rocx,rocy,NPR,recall,AUC]=calculateROC(output)


%--------------------------------------------------------------------------
% calculateROC

% Last updated: July 2016, J. LaRocco

% Details: Calculate ROC curve from index.

% Usage:
% [rocx,rocy,NPR,recall]=calculateROC(output)

% Input:
%  output: Struct full of output data. (struct)

% Output:
%  NPR: negative predictive rate-x label
%  recall: recall-y label
%  rocx: rocx coefficient of ROC curve
%  rocy: rocy coefficient of ROC curve
%  AUC: area under curve

%--------------------------------------------------------------------------

TP=output.C1.tp;
TN=output.C1.tn;
FP=output.C1.fp;
FN=output.C1.fn;

recall=TP./(TP+FN);
specificity=TN./(TN+FP);
isnanmask=isnan(recall) | isnan(specificity);
recall=recall(~isnanmask);
specificity=specificity(~isnanmask);
NPR=1-specificity;

x=[1 1 0 NPR];
y=[1 0 0 recall];

dt=delaunayTriangulation(x',y');
[convexPts,AUC]=convexHull(dt);

rocx=x(convexPts);
rocy=y(convexPts);

end