function [smoothed,ws,sigmaFreq,gabors] = mpRDReconstruct(EEG,channel_index,values,bounds,scales)

%--------------------------------------------------------------------------
% mpRDReconstruct

% Last updated: September 2016, J. LaRocco

% Details: MP reconstruction of EEG with restricted dictionary.

% Usage:
% [smoothed,ws,sigmaFreq,gabors] = mpRDReconstruct(EEG,channel_index,values,bounds,scales)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales: scales of gabor atoms in a positive vector [0.5 1 2]

% Output:
%  smoothed: MP reconstruction (matrix of channels by samples)
%  ws: MP atom coefficients (matrix of dimensions of channel by gabors)
%  sigmaFreq: 2 column matrix with scale values in first column and freq in second column
%  gabors: Gabor functions used as basis
%--------------------------------------------------------------------------

bounds=sort(bounds,'ascend');
lbound=bounds(1);
ubound=bounds(2);

deviationFactor = 3;  %Number of standard deviations for the support
srate = EEG.srate;
frequencies = lbound:ubound;
numberScales = length(scales);
numberFreq = length(frequencies);
numberGabors = numberFreq*numberScales;
sigmaFreq = zeros(numberGabors, 2);
k = 1;
for n = 1:numberScales
    for m = 1:numberFreq
        sigmaFreq(k, 1) = 0.5*scales(n);
        sigmaFreq(k, 2) = frequencies(m);
        k = k + 1;
    end
end

maxSD = max(scales)/2;

t = -deviationFactor*maxSD:1/srate:deviationFactor*maxSD;  % time in seconds

%% Create Gabors
gabors = zeros(length(t), numberGabors);
for k = 1:numberGabors
    factor = sigmaFreq(k, 1)*sqrt(2*pi);
    gabors(:, k) = exp(-.5*(t.^2)*sigmaFreq(k, 1).^(-2)).*cos(2*pi*t*sigmaFreq(k, 2))./factor;
end

atoms=values;
smoothed=zeros(length(channel_index),size(EEG.data,2));
ws=zeros(length(channel_index),size(EEG.data,2),size(gabors,2));
for k = 1 : length(channel_index)
    
    [ws(k,:,:),smoothed(k,:)] = temporalMP(prototype_cleanup(EEG.data(channel_index(k),:)'),gabors,false,atoms); clc;
    
end



end



