function [mu, sigma, score, A] = SDAR(data, order, r, trainIndex, lossFunction)
% SDAR       estimates a signal using the Sequential Discounting AR Model
%
% Input:
%     data            A vector of time series to model
%     order           order of the SDAR model. Default is order = 1.
%     r               Discounting rate, from (0,1). Default is r = .001
%     trainIndex      An index of points to estimate the initial conditions
%                     for the SDAR algorithm. 
%                     Example: trainIndex = 1 : 1000;
% Output:
%     mu              The estimated mean of the SDAR model at each time
%                     point. This is taken as an estimate of the original 
%                     signal.
%     sigma           The estimated variance of the SDAR model at each time
%                     point. Take the sqrt to get the standard deviation. 
%     loss            The predicted loss of the original signal vs the
%                     estimated signal usind SDAR. This is calculated using
%                     the quadratic loss function. Other functions can be
%                     used (see notes). 
%       A             The estimated SDAR Coefficients. 
%   
% Notes:
%
%  1. Algorithm for estimating the SDAR model is from Urabe et. al. (2012)
%     Real-Time Change-Point Detection Using Sequentially Discounting 
%     Normalized Maximum Likelihood Coding.
%
%  2. The original ChangeFinder algorithm is described here:
%
%     Takeuchi, J. and Yamanishi, K. A Unifying Framework for Detecting 
%     Outliers and Change Points from Time Series. IEEE Transactions on
%     Knowledge and Data Engineering. 18(4), 2006. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% data must be a column vector;
if size(data, 2) ~= 1
    data = data';
end

% set the loss function 
if strcmp(lossFunction, 'quadratic')
    lossFunction = @quadloss;
elseif strcmp(lossFunction, 'log')
    lossFunction = @logloss;
else
    error('Specified loss function not found');    
end


% data should be double
data = double(data);

% the time series must be 0 mean. 
data = data - mean(data);

% get initial estimates using Burg AR method. 
% w = mean estimate, A_burg is AR estimate, C_burg variance estimate
[w, A_burg, C_burg] = arfit2(data(trainIndex), order, order);  %#ok<ASGLU>

% pre-allocation, T, V, M, c taken from Urabe et. al. (2012)
T = length(data);
V = zeros(order, order, T);
M = zeros(order, T);
c = zeros(T, 1);
mu = zeros(T, 1);
sigma = zeros(T, 1);
score = zeros(T, 1);

% setting the initial conditions
V(:,:,order) = eye(order);
M(:,order) = A_burg';
sigma(1:order) = C_burg;
A(:, 1:order) = repmat(A_burg', 1, order);

% calculate the mean and standard deviation of signal in first time step
mu(order) = A(:,order)'*data(order : - 1 : 1);

if order == 1
    sigma(order) = C_burg;
else
    sigma(order) = (1 - r) * sigma(order - 1) + r * ...
       (data(order) - mu(order))*(data(order) - mu(order))';
end

c(order+1) = r * data(order : -1 : 1)'*V( :, :, order) * data(order : -1 : 1);

V(:,:,order+1) = (1/(1-r))*V(:,:,order) - (r/(1-r))*((V(:,:,order)*...
    (data(order:-1:1)*data(order:-1:1)')*V(:,:,order))/(1 - r + c(order+1)));


for i = order + 1: T
    xbar = data(i-1:-1:i-order);

    % now calculate the iteration to update the parameters
    M(:,i) = (1-r)*M(:,i-1) + r*xbar*data(i);
    c(i) = r*xbar'*V(:,:,i-1)*xbar;
    V(:,:,i) = (1/(1-r))*V(:,:,i-1) - (r/(1-r))*((V(:,:,i-1)*(xbar*xbar')*...
        V(:,:,i-1))/(1 - r + c(i)));
    A(:,i) = V(:,:,i)*M(:,i);

    % update the mean and variance, make one step prediction
    mu(i) = A(:,i)'*xbar;
    sigma(i) = (1-r)*sigma(i-1) + r*(data(i)-mu(i))*(data(i)-mu(i))';
    score(i) = lossFunction(data(i), mu(i-1), sqrt(sigma(i-1)));
end


end


function loss = quadloss(data, mu, sigma) %#ok<INUSD>

loss = (data - mu).^2;

end


function loss = logloss(data, mu, sigma)

loss = -log(normpdf(data, mu, sigma));

end
