function  [output]=spindledetectorShortScale(EEG,channel_index,expert_events,values)

%clear; close; clc;


%%BANDPASS FILTER SIGNAL AND TAKE RECONSTRUCTION

%EEG = pop_loadset(filename);

%clear; close; clc;
%%SIMPLE RECONSTRUCTION OF SIGNAL IS USED
%%
% EEG = pop_loadset('data/alphasim_SNR1.set');
%EEG = pop_loadset('data/driving-data1.set');
% EEG = pop_loadset('data/driving-data2v3-secondhalf.set');
% EEG = pop_loadset('data/VEP-data1-secondhalf.set');
% EEG = pop_loadset('data/VEP-data2-secondhalf.set');
% EEG = pop_loadset('data/alphasim_SNR2.set');
%%
%channel_index = [25:26];
% channel_index = [20:31 57:64] ;
% mu = zeros(length(channel_index), size(EEG.data, 2));
% sigma = zeros(length(channel_index), size(EEG.data, 2));
% loss = zeros(length(channel_index), size(EEG.data, 2));
order = 2;
% A = zeros(length(channel_index), 1:order,  size(EEG.data, 2));

for i = 1 : length(channel_index)
    tic;
    %[mu(i,:), sigma(i,:), loss(i,:), A(i,1:order,:)] = SDARv3(EEG.data(channel_index(i),:), order, .001, 1:100);
    toc;
end

%%
% clear smoothed;
% for k = 1 : length(channel_index)
%     smoothed(k,:) = temporalSmooth(loss(k,:), 10, 5, @mean);
% end


%bounds=[6 18];
bounds=[1 ceil(EEG.srate/2.1)];
bounds=sort(bounds,'ascend');
lbound=bounds(1);
ubound=bounds(2);
f=lbound:.5:ubound;


fs=EEG.srate;
  EEG = removeTrend(EEG); clc;   
    EEG = fastPreproc(EEG); clc;
    EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;
t=(ceil(-.5*fs):1:ceil(.5*fs))';
%f=8:1:18;
s=10*ones(1,length(f));
gabors = exp(-pi*(t.^2)'*s.^(-2)).*cos(2*pi*t*f./fs);
clear smoothed;
%values=[100 500 1000 2000 5000 10000 15000 30000 50000 90000];
%values=1500:250:5000;
ka=1;
x=[]; Tp=[]; Tn=[]; Fp=[]; Fn=[];
for ka=1:length(values);
atoms=values(ka);
clear smoothed;
for k = 1 : length(channel_index)
    
    yith=EEG.data(channel_index(k),:);
    %yith=epochs(:,k);
    
    
    
    [ws,yhat] = temporalMP(prototype_cleanup(yith'),gabors,false,atoms); clc;
    
    smoothed(k,:) = yhat;
    %smoothed(k,:) = moving_average(loss(k,:), 5);
end

%%
% load data/B_16_VEP2.mat
%load data/subject1010v2;
% load data/S1015_BL_CNT2.mat;
% load data/B_06_VEP2;
%  clear sensitivity1 specificity1 precision1 recall1;
% load data/alphasim_events;
%278 - VEP1, 1429 - Driving2, 1935 - Driving1
% 
% t1 = find(cell2mat(expert_events(:,3))<1935);
% expert_events1 = expert_events(1:t1(end), :);
% expert_events2 = expert_events(t1(end)+1:end,:);
% 
% for i = 1 : size(expert_events2,1)
%     expert_events2{i, 2} = expert_events2{i,2} - 1935;
%     expert_events2{i, 3} = expert_events2{i,3} - 1935;
% end
%     

%%

thresholds = [0.00001 .01:.01:1];
for K = 1 : length(thresholds)
   % fprintf('K = %d\n', K);
    events = applyThreshold(smoothed, 128, thresholds(K), 1/3);
    new_events = combineEvents(events, .25, .25);
    % plotMarkedData(EEG, new_events);
    

    [a,b,c] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
%     [a,b,c] = compareLabels(EEG, expert_events, events, 0.1, EEG.srate);

    sensitivity1(K) = c.agreement/(c.agreement + c.falseNegative);
    specificity1(K) = c.nullAgreement/(c.nullAgreement+c.falsePositive);
    precision1(K) = c.agreement/(c.agreement+c.falsePositive);
    recall1(K) = c.agreement/(c.agreement+c.falseNegative);
%     
%     agreements(K) = c.agreement;
%     nullagreements(K) = c.nullAgreement;
    
end
%%
% 
% figure(2);
% plot(1-specificity1, sensitivity1, 'linewidth', 3); hold on;
% plot(0:1/length(thresholds):1-1/length(thresholds), linspace(0, 1, length(thresholds)), '-.', 'linewidth', 2);
% set(gca, 'fontweight', 'bold', 'fontsize', 14)
% xlabel('1 - Specificity')
% ylabel('Sensitivity')
% title('ROC Curve')
% hold off;
% axis([-.05 1.05 -.05 1.05])

beta1 = 2;
f1 = (1 + beta1^2).*(precision1.*recall1)./((beta1^2.*precision1) + recall1);
% 
% 
% figure(3);
% plot(thresholds, f1, 'linewidth', 3)
% set(gca, 'fontweight', 'bold', 'fontsize', 14)
% xlabel('Threshold Value');
% ylabel('Modified F-Measure');
% title('Modified F-Measure vs Threshold Value')
[a,b] = max(f1);


%%
 events = applyThreshold(smoothed, 128, thresholds(b), 1/3);
new_events = combineEvents(events, .25, .25);

[a1,b1,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);

%      
%  fprintf('Precision = %1.3f\n', c1.agreement/(c1.agreement+c1.falsePositive));
%  fprintf('Recall = %1.3f\n', c1.agreement/(c1.agreement+c1.falseNegative));
%  fprintf('Sensitivity = %1.3f\n', c1.agreement/(c1.agreement+c1.falseNegative));
%  fprintf('Specificity = %1.3f\n', c1.nullAgreement/(c1.nullAgreement+c1.falsePositive));
% 
%  
 %%
 EEG.event = [];
 temp1(size(expert_events,1)).type = [];
 temp1(size(expert_events,1)).latency = [];
 
 for i = 1 : size(expert_events, 1)
 temp1(i).type = 'start';
 temp1(i).latency = cell2mat(expert_events(i, 2))*EEG.srate;
     
 end
 
 for j = i+1 : 2*size(expert_events, 1)
 temp1(j).type = 'end';
 temp1(j).latency = cell2mat(expert_events(j-size(expert_events, 1), 3))*EEG.srate;
     
 end
 EEG.event = temp1;
 
 
 %% calculate hit rate
 temp10 = min(cell2mat(new_events(2:end,2))-cell2mat(new_events(1:end-1, 3)));
 %[a2, b2, c2] = compareLabels(EEG, new_events, expert_events2, temp10, EEG.srate);
 %t1 = strcmp(a2(:,1), 'Agreement');
 %sum(t1)/size(expert_events2, 1)
 

 precision2=c1.agreement/(c1.agreement+c1.falsePositive);
 recall2=c1.agreement/(c1.agreement+c1.falseNegative);
 sensitivity2=c1.agreement/(c1.agreement+c1.falseNegative);
 specificity2=c1.nullAgreement/(c1.nullAgreement+c1.falsePositive);
 
tp=c1.agreement;
tn=c1.nullAgreement;
fp=c1.falsePositive;
fn=c1.falseNegative;


Tp=[Tp; tp];
Tn=[Tn; tn];
Fp=[Fp; fp];
Fn=[Fn; fn];     

 
 
 [phi,roc,auc_roc,accuracy,sensitivity,specificity,acc2,ppv,npv]=correctOutputs(tp,tn,fp,fn);
  f1=2*(ppv*npv)./(ppv+npv);
 x(:,ka)=[atoms; phi; sensitivity; specificity; ppv; npv; f1];
 %x(:,ka)=[sensitivity2; specificity2; precision2; recall2];
 end
 output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1','Type','WholeDictionaryShortScale','Bounds',bounds,'TP',Tp,'TN',Tn,'FP',Fp,'FN',Fn);
% save('ASDetector3_GMPReconstruction.mat','output');
end 
 
 