function  [output]=spindledetectorAdjustROC(EEG,channel_index,expert_events,values,bounds,scales)

%%BANDPASS FILTER SIGNAL AND TAKE RECONSTRUCTION


%--------------------------------------------------------------------------
% SPINDLEDETECTORADJUST

% Last updated: May 2016, J. LaRocco

% Details: Spindle detection system using matching pursuit reconstruction
% with custom parameters.

% Usage:
% [output]=spindledetectorAdjust(EEG,channel_index,expert_events,values,bounds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  channel_index: A matrix of channels to limit analysis to.
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  values: total number of atoms to use in reconstruction. (Scalar, positive integer)
%  bounds: frequency boundry to restrict reconstruction to. (1x2 vector with positive integers, e.g.,[6 14])
%  scales: length of Gabor atoms (scalar, positive integer)

% Output:
%  output: Output performance in struct.

%--------------------------------------------------------------------------


%% reconstruct signal

bounds=sort(bounds,'ascend');

EEG = removeTrend(EEG); clc;
EEG = fastPreproc(EEG); clc;
EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;


%% reconstruct signal
[smoothed] = mpRDReconstruct(EEG,channel_index,values,bounds,scales);

%% Apply threshold for classification

thresholds=linspace(min(min(smoothed)),max(max(smoothed)),100);
%thresholds = [0.00001 .01:.01:1];
atoms=values;

[c1]=compareThresholdROC(EEG, expert_events, smoothed, thresholds);

%% calculate hit rate
precision2=c1.agreement/(c1.agreement+c1.falsePositive);
recall2=c1.agreement/(c1.agreement+c1.falseNegative);
%sensitivity2=c1.agreement/(c1.agreement+c1.falseNegative);
%specificity2=c1.nullAgreement/(c1.nullAgreement+c1.falsePositive);

tp=(c1.agreement);
tn=(c1.nullAgreement);
fp=(c1.falsePositive);
fn=(c1.falseNegative);
tt=(c1.totalTime);

beta1 = 2;
f1 = (1 + beta1^2).*(precision2.*recall2)./((beta1^2.*precision2) + recall2);

[phi,~,~,accuracy,sensitivity,specificity,~,ppv,npv]=correctOutputs(tp,tn,fp,fn);

x=[atoms; phi; sensitivity; specificity; ppv; npv; f1; accuracy];

output=struct('C1',{c1},'data',x,'dataformat','atoms,phi,sensitivity,specificity,ppv,npv,f1,accuracy','Type','RestrictedDictionaryandBandpassROC','Bounds',bounds,'TP',tp,'TN',tn,'FP',fp,'FN',fn,'totalTime',tt);

end

