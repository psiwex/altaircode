function EEG = fastPreproc(EEG)
% Extract the EEG
%
%  Parameters:
%     filename  EEGLAB EEG structure

%   Output:
%     EEG     EEGLAB EEG structure with the output
%
%   Written by:  John LaRocco, Feb 2016
%
% Assumes:  Overhead is same as North America, 60 Hz.

%%Baseline Removal
x=EEG.data;
[chans,~]=size(x);

for i=1:chans;
    x1=mean(x(i,:));
    xx=x(i,:)-x1;
    x(i,:)=xx;
end

%% Line noise removal
%    overhead=60;
%    duplicates=floor((EEG.srate/2)/overhead);
%    lineNoise=overhead*(1:duplicates);
%     spread=1;
%
%     fRange=spread*ones(1,length(lineNoise));
%     for i=1:chans;
%         x(i,:) = blasst(x(i,:),lineNoise,fRange,EEG.srate);
%     end
 x=x/max(max(x));

EEG.data=x;
end
