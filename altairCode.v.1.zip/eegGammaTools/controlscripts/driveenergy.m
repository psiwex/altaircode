%dreams energy

filename='data/driving-data1.set';
load data/subject1010v2;
channel_index = [25:26];
atoms=200;
bounds=[6 18];

EEG = pop_loadset(filename);
clc;
subnum=11;
[output]=spindledetectorSDARROC(EEG,channel_index,expert_events);
TP=output.C1.tp;
TN=output.C1.tn;
FP=output.C1.fp;
FN=output.C1.fn;

recall=TP./(TP+FN);
specificity=TN./(TN+FP);
NPR=1-specificity;

x=[1 0 1 NPR];
y=[0 0 1 recall];

dt=delaunayTriangulation(x',y');
convexPts=convexHull(dt);

%x=x(2:end);
%y=y(2:end);
%convexPts=convexPts(2:end);

rocx=x(convexPts);
rocy=y(convexPts);

h=figure;
plot(rocx,rocy)


xlabel('False Positive Rate')
ylabel('True Positive Rate')

name=['ROC Curve for DAR on EEG (Driving Subject 1)'];
%name=['ROC Curve for DAR on EEG (driving-data1.set)'];
name2='rocdrive';
title(name)
saveas(h,name2,'jpg');
saveas(h,name2,'fig');
saveas(h,name2,'eps');




[evector]=energyWindow(EEG.data(channel_index,:), EEG.srate);
%evector=evector/max(evector);

h=figure;
plot(abs(evector))
xlabel('Time (s)')
ylabel('Power (db)')

name='Power for Time for EEG (Driving Subject 1)';
%name=['ROC Curve for DAR on EEG (driving-data1.set)'];
name2='drivepx';
title(name)
saveas(h,name2,'jpg');
saveas(h,name2,'fig');
saveas(h,name2,'eps');