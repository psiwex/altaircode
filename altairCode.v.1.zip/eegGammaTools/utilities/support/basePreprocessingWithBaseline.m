function [EEG] = basePreprocessingWithBaseline(EEG)
%John LaRocco


%--------------------------------------------------------------------------
% basePreprocessingWithBaseline

% Last updated: Feb 2016, J. LaRocco

% Details: Function performs preprocessing with baseline removal and detrending. 

% Usage: [EEG] = basePreprocessingWithBaseline(EEG)

% Input:
%  EEG: a struct of EEG data. 

% Output:
% EEG: a struct of final EEG data. 

%--------------------------------------------------------------------------

%%Preprocessing
%% Where the file is preprocessed.     
    EEG = removeTrend(EEG); clc;   
    EEG = fastPreproc(EEG); clc;
    EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;
    EEG = eeg_checkset(EEG); clc;
    
    
end