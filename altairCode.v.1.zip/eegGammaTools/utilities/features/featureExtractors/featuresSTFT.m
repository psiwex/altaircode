function [Pxx,power]=featuresSTFT(segments,fs)

%load('featureset.mat','x');
%segments=x';
%--------------------------------------------------------------------------
% FEATURESSTFT

% Last updated: Feb 2016, J. LaRocco

% Details: Feature extraction method, taking data from multiple periodograms using STFT.

% Usage: [y]=featuresSTFT(segments,fs)

% Input:
%  segments: Matrix of EEG data.
%  fs: sampling frequency.

% Output:
% Pxx: Pxx is the spectral features like found in the Peiris paper.
% power: matrix of raw power spectrums.

%--------------------------------------------------------------------------


%% Initializing
Pxx=[];
power=[];
[coef,inst]=size(segments);

Pxx=zeros(34,inst);

for i=1:1:inst
    
    %x=segments(:,i);
    
    pv=stftham(segments(:,i)',fs);
    spec_coefs=pow2db(abs(pv));
    
    
    if i==1
        power=zeros(length(spec_coefs),inst);
    end
    
    power(:,i)=spec_coefs;
    maxSpectralCoef=max(spec_coefs);
    

    Pxx(:,i)=featureSpecAdjust(spec_coefs,fs);
    
    
    % %
end
%
%
% end




end