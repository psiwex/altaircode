function [c1]=compareThresholdAtom(EEG, expert_events, smoothed, thresholds, channel_index, values, bounds, scales1)


%--------------------------------------------------------------------------
% compareThresholdAtom

% Last updated: June 2016, J. LaRocco

% Details: MP reconstruction of EEG with restricted dictionary.

% Usage:
% [c1]=compareThresholdAtom(EEG, expert_events, smoothed, thresholds)

% Input:
%  EEG: Input EEG struct. (EEGLAB format)
%  expert_events: struct with expert-rated times and durations for spindles (scalar or vector of positive integers).
%  smoothed: reconstruction of EEG data (vector)
%  threshold: vector of values to explore for threshold (vector)
% Output:
%  c1: struct with final results

%--------------------------------------------------------------------------
%size(smoothed)
%size(EEG.data)

%EEG.data(channel_index,:)=X;

    %EEG.data=smoothed;

    [rating,coef,sigmaFreq,thresholds] = unsupervisedSpindleDetectorThreshold(EEG,channel_index,values,bounds,scales1);




    events = applyThresholdBinary(EEG.srate, rating);
    if isempty(events)
%        continue
    end
    new_events = combineEvents(events, .25, .25);

    EEG.data=smoothed;    

    [~,~,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
    b=1;
    
    TP=c1.agreement;
    TN=c1.nullAgreement;
    FP=c1.falsePositive;
    FN=c1.falseNegative;
% 
% %% Apply threshold for classification
% TP=zeros(1,length(thresholds));
% TN=zeros(1,length(thresholds));
% FP=zeros(1,length(thresholds));
% FN=zeros(1,length(thresholds));
% phi=zeros(1,length(thresholds));
% 
% for K = 1 : length(thresholds)
%     %Px=pow2db(sum(abs(fft(coef(1,:).^2)))/length(coef));
%     
%     
%     
%     events = applyThresholdBinary(EEG.srate, rating);
%     if isempty(events)
%         continue
%     end
%     new_events = combineEvents(events, .25, .25);
%     
%     
%     [~,~,c] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);
%     
%     labels=zeros(1,length(smoothed));
%     scores=labels;
%     
%     [keyEvents,~]=size(expert_events);
%     [newEvents,~]=size(new_events);
%     for ja=1:keyEvents;
%         keystart=expert_events{ja,2};
%         keyend=expert_events{ja,3};
%         
%         lb=ceil(EEG.srate*keystart);
%         ub=ceil(EEG.srate*keyend);
%         labels(lb:ub)=1;
%         
%     end
%     
%     for jb=1:newEvents
%         
%         lb=ceil(EEG.srate*keystart);
%         ub=ceil(EEG.srate*keyend);
%         scores(lb:ub)=1;
%     end
%     
%     tp=(c.agreement);
%     tn=(c.nullAgreement);
%     fp=(c.falsePositive);
%     fn=(c.falseNegative);
%     
%     TP(K)=tp;
%     TN(K)=tn;
%     FP(K)=fp;
%     FN(K)=fn;
%     [phi(K),~,~,~,~,~,~,~,~]=correctOutputs(tp,tn,fp,fn);
%     
%     
%     
% end
%% tally up performance metrics

%aucroc=recall1.*NPR1;
% [~,b] = max(phi);

%%
%events = applyThresholdBinary(EEG.srate, rating);

%new_events = combineEvents(events, .25, .25);

%[~,~,c1] = compareLabels(EEG, expert_events, new_events, 0.1, EEG.srate);

%%
EEG.event = [];
temp1(size(expert_events,1)).type = [];
temp1(size(expert_events,1)).latency = [];

for i = 1 : size(expert_events, 1)
    temp1(i).type = 'start';
    temp1(i).latency = cell2mat(expert_events(i, 2))*EEG.srate;
    
end

for j = i+1 : 2*size(expert_events, 1)
    temp1(j).type = 'end';
    temp1(j).latency = cell2mat(expert_events(j-size(expert_events, 1), 3))*EEG.srate;
    
end

EEG.event = temp1;
c1.selectedthreshold=thresholds(b);
c1.thresholdvalues=thresholds;
c1.threshold=thresholds(b);
c1.thresholds=thresholds;
c1.tp=TP;
c1.tn=TN;
c1.fp=FP;
c1.fn=FN;
c1.coef=coef;
%c1.Px=Px;
c1.rating=rating;
c1.coef=coef;
c1.sigmaFreq=sigmaFreq;

end