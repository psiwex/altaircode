% test script: plot freq vs amplitude, 20 sec classification, test script
% 1000 atoms, 1000 scale freqs, in 20 s window
% histogram of ws amplitudes, each window, hist(x), fix bin range, two
% return arguments to hist, gives counts and positions of the bins. 

%can do for each window, counts can be added. Overall distribution of
%amplitudes of atoms over all windows. plot as bar. 

%% initialize variables
clear; clc; close;
subnum=1;
%scales1=[.125 .25 .5];
%scales1=[.25 .5 1 1.5 2 2.5];
%scales1=[.5 1 1.5 2 2.5];
scales=[.5 2.5];
bounds=[12 15];
atoms=200;
jj=atoms;
values=jj;
scales1=linspace(scales(1),scales(end),values/length(bounds(1):bounds(end)));

%values=length(scales1)*length(bounds(1):bounds(end));
threshold=2*max(max(scales1));
maxatoms=2000;
ss=0;
scales=scales1(1:(length(scales1)-ss));
%% load file
filename=['excerpt' num2str(subnum) '.set'];
clc;
EEG = pop_loadset(filename);

EEG=pop_resample(EEG,128);
expertname=['expert_events' num2str(subnum) '.mat'];

load(expertname);

if subnum>6
    
    channel_index = 3;
    
else
    channel_index=1;
    
end


bounds=sort(bounds,'ascend');

EEG = removeTrend(EEG); clc;
EEG = fastPreproc(EEG); clc;
EEG = pop_eegfiltnew(EEG,1,ceil(EEG.srate/2.1)); clc;

%% binary rating vector

rating=zeros(1,size(EEG.data,2));
eventnumbers=size(expert_events,1);
eventstart=zeros(1,eventnumbers);
eventdur=zeros(1,eventnumbers);
sampleStart=zeros(1,eventnumbers);
sampleEnd=zeros(1,eventnumbers);

sampleTEnd=zeros(1,eventnumbers);

lengthSec=20;

for u=1:eventnumbers;
    
    eventstart(u)=expert_events{u, 2};
    eventdur(u)=expert_events{u, 3};
    sampleStart(u)=ceil(EEG.srate*eventstart(u));
    sampleEnd(u)=sampleStart(u)+ceil(lengthSec*EEG.srate);
    sampleTEnd(u)=ceil(EEG.srate*eventdur(u));    
    rating(sampleStart(u):sampleEnd(u))=1;
end



%rating(rating==0)=-1;
sig=rating;
emptyVec=-1*ones(1,ceil(lengthSec*EEG.srate));
%tsig = (abs(sig) >= 0.5);
tsig=sig;
dsig = diff([1 tsig 1]);
startIndex = find(dsig < 0);
endIndex = find(dsig > 0)-1;
duration = endIndex-startIndex+1;
stringIndex = (duration >= ceil(lengthSec*EEG.srate));
startIndex = startIndex(stringIndex);
endIndex = endIndex(stringIndex);


%% sorting the epochs

numberEpochs=10; %number of epochs of each category to grab

%nullCases=[startIndex(1:numberEpochs); endIndex(1:numberEpochs)];
eventCases=[sampleStart(1:numberEpochs); sampleEnd(1:numberEpochs)];

%totalCase=[nullCases eventCases];
totalCase=eventCases;
totalKey=[zeros(1,numberEpochs) ones(1,numberEpochs)];

[~,~,sigmaFreq] = mpRDReconstruct(EEG,channel_index,values,bounds,scales);

coeffs=[];

%for j=1:(2*numberEpochs);
    j=2; 
    EEG1=EEG;
    x=EEG.data(channel_index,totalCase(1,j):totalCase(2,j));
    EEG1.data=double(x)/max(max(x));
    [~,ws,~] = mpRDReconstruct(EEG1,channel_index,values,bounds,scales);
    coeffs{j}=ws;
    
%end
%% 1 epoch test
xtest=squeeze(ws);
%figure;
%y=repmat(1:length(sigmaFreq),size(xtest,1),1);
%plot(y,abs(xtest),'xk');

%% timepoints
   atomMask=(xtest>threshold);
%sum(sum(atomMask))
[row,column]=find(atomMask);

%% next
figure;
t=(1:size(xtest,1))/EEG.srate;
trep=repmat(t',1,size(xtest,2));
plot(trep,abs(xtest),'xk');

%% histogram
%[counts,centers]=hist(abs(xtest(:)),100);

%figure;
%bar(abs(xtest'));
%hist(abs(xtest(:)))
y=abs(xtest(:));
y(y<0.1)=[];

%% new cell
figure;
[counts,centers]=hist(y);
plot(centers, (counts))
%% fitting
%pd=fitdist(y,'exponential');
figure;
pd=probplot('exponential',y);

% save arrays to cells
