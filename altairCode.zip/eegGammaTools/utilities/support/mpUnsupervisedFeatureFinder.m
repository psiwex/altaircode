function [bar,featurelist,bars] = mpUnsupervisedFeatureFinder(ws,channel_index,featurestouse)

%--------------------------------------------------------------------------
% mpUnsupervisedFeatureFinder

% Last updated: August 2016, J. LaRocco

% Details: MP unsupervised feature finding and threshold ranking.

% Usage:
% [bar,featurelist] = mpUnsupervisedFeatureFinder(ws,channel_index)

% Input:
%  ws: a matrix of MP coefficients (matrix of channels by time by freq/scale)
%  channel_index: A vector of channels to limit analysis to.
%  featurestouse: Number of features to retain (scalar)

% Output:
%  bar: final threshold value.
%  featurelist: List of ranked features in descending order.
%  bars: channel thresholds
%--------------------------------------------------------------------------

maxlocs=zeros(2,length(channel_index));
maxvalues=zeros(1,length(channel_index));
featurelist=zeros(featurestouse,length(channel_index));
bars=zeros(1,length(channel_index));
for k = 1 : length(channel_index)
    x=squeeze(ws(channel_index(k),:,:));
    maxvalues(k)=max(max(abs(x)));
    x1=x/maxvalues(k);
    [ro,col]=find(x1==1);
    maxlocs(1,k)=ro;
    maxlocs(2,k)=col;
    xx=reshape(x,1,size(x,1)*size(x,2));
    xx=sort(xx,'descend');
    xx=xx(1,1:featurestouse);
    featurelist(:,k)=xx;
    bars(k)=.75*(maxvalues(k)-mean(mean(x)));
end
bar=mean(bars);


end



