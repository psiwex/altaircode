function  [Pxx]=powerEstimator(dataMatrix,windowLength,windowIncrement,Fs)

%clear; close; clc;
% this new program calculates the power based in provided window length and
% increment.
%--------------------------------------------------------------------------
% POWERESTIMATOR

% Last updated: May 2016, J. LaRocco

% Details: Calculate power of each channel based on a window.

% Usage:
% pxx=powerEstimator(dataMatrix,windowLength,windowIncrement,Fs)

% Input:
%  dataMatrix: a matrix of EEG data (sorted in dimensions channels by samples)
%  windowLength: length of the windows (length in seconds)
%  windowIncrement: how fast the window increment shifts (length in seconds)
%  Fs: sampling frequency (samples per second)

% Output:
%  Pxx: power estimates for each channel, sorted in channels by power per window.

%--------------------------------------------------------------------------

%% calculate necessary values


windowLengthSample=floor(windowLength*Fs);
windowIncrementSample=floor(windowIncrement*Fs);


if windowLengthSample==0;
    windowLengthSample=1;
end


if windowIncrementSample==0;
    windowIncrementSample=1;
end



[channels,samples]=size(dataMatrix);
numberOfWindows=floor(samples/windowIncrementSample);
loBound=1:windowIncrementSample:abs(1+((numberOfWindows-1)*windowIncrementSample));
hiBound=windowLengthSample:windowIncrementSample:abs(numberOfWindows*windowLengthSample);
hiBound=hiBound(1:length(loBound));
hiBound(end)=samples;
hiBound(hiBound>samples)=samples;
Pxx=zeros(channels,length(hiBound));

   
%% isolate each channel

    %% calculate power
    
    for ik=1:length(loBound);
        sig1=dataMatrix(:,loBound(ik):hiBound(ik));
        Pxx(:,ik)=sum(abs(fft(sig1,[],2)).^2,2)/(hiBound(ik)-loBound(ik)+1);
    end
    
   

end