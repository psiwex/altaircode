function [evector]=energyWindow(data, fs)


%--------------------------------------------------------------------------
% energyWindow

% Last updated: July 2016, J. LaRocco

% Details: Windowed energy calculation
% Usage:
% [evector]=energyWindow(data, fs)

% Input:
%  data: Input EEG data. (vector of EEG)
%  fs: sampling frequency (scalar or vector of positive integers).
%  smoothed: reconstruction of EEG data (vector)
%  threshold: vector of values to explore for threshold (vector)
% Output:
%  evector: vector of energy power


%--------------------------------------------------------------------------

dataLength=length(data);

lb=1:fs:ceil(dataLength-fs);
ub=fs:fs:dataLength;
ub=ub(1:ceil(-1+dataLength/fs));

lb=lb(1:ceil(-1+dataLength/fs));
evector=zeros(1,ceil(dataLength/fs));
for K=1:ceil(-1+dataLength/fs)
    evector(K)=pow2db(sum(abs(fft(data(1,lb(K):ub(K)).^2)))/length(data));
end




end